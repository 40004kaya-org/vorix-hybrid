#!/data/data/com.termux/files/usr/bin/bash
# VSEC-RUN — Termux Edition

VORIX_HOME="$HOME/vorix"
LOG_DIR="$VORIX_HOME/logs/security"
LOG_FILE="$LOG_DIR/gate09.jsonl"
mkdir -p "$LOG_DIR"

GREEN='\033[0;32m'; BLUE='\033[0;34m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'

TOOL="$1"
shift

if [ -z "$TOOL" ]; then
    echo -e "${RED}Usage: vsec-run <tool> [args...]${NC}"
    echo "Tools: vscan (nmap), vbanner, vdirb"
    exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
EVENT_ID="evt-$(date +%s%N | sha256sum | head -c 16)"
CORR_ID="corr-$(date +%s%N | sha256sum | head -c 16)"

# لاگ شروع
printf '{"timestamp":"%s","event_id":"%s","severity":"INFO","gate":"GATE01","module":"TOOL","event_type":"EXEC_START","result":"PASS","correlation_id":"%s","message":"Starting %s %s","metadata":{"tool":"%s","args":"%s"}}\n' \
    "$TIMESTAMP" "$EVENT_ID" "$CORR_ID" "$TOOL" "$*" "$TOOL" "$*" >> "$LOG_FILE"

echo -e "${BLUE}▶ Running: $TOOL $*${NC}"
echo "════════════════════════════════════════"

START=$(date +%s)

case "$TOOL" in
    vscan|nmap)
        TARGET="${1:-127.0.0.1}"
        PORTS="${2:-1-1024}"
        # پشتیبانی از فرمت‌های مختلف
        case "$PORTS" in
            *-*) RANGE="$PORTS" ;;
            *)   RANGE="$PORTS" ;;
        esac
        OUTPUT=$(nmap -p "$RANGE" "$TARGET" 2>&1)
        ;;
    vbanner)
        # اگر vbanner در Termux نداریم، از nmap استفاده می‌کنیم
        TARGET="${1:-127.0.0.1}"
        PORTS="${2:-80,443}"
        OUTPUT=$(nmap -sV -p "$PORTS" "$TARGET" 2>&1)
        ;;
    vdirb)
        TARGET="${1:-http://example.com}"
        OUTPUT=$(curl -s -I "$TARGET" 2>&1)
        ;;
    *)
        echo -e "${RED}❌ Unknown tool: $TOOL${NC}"
        exit 1
        ;;
esac

EXIT_CODE=$?
END=$(date +%s)
DURATION_MS=$(( (END - START) * 1000 ))

echo "$OUTPUT"

OPEN_COUNT=$(printf '%s' "$OUTPUT" | grep -cE "[0-9]+/tcp\s+open" 2>/dev/null)
OPEN_COUNT=${OPEN_COUNT:-0}
if [ "$OPEN_COUNT" = "" ]; then OPEN_COUNT=0; fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [ "$EXIT_CODE" -eq 0 ]; then
    SEVERITY="INFO"
    RESULT="PASS"
else
    SEVERITY="ERROR"
    RESULT="FAIL"
fi

if [ "$OPEN_COUNT" -gt 5 ]; then
    SEVERITY="CRITICAL"
fi

# لاگ پایان
printf '{"timestamp":"%s","event_id":"evt-%s","severity":"%s","gate":"GATE01","module":"TOOL","event_type":"EXEC_COMPLETE","result":"%s","correlation_id":"%s","message":"%s finished: %s open","metadata":{"tool":"%s","exit":%s,"duration_ms":%s,"open":%s}}\n' \
    "$TIMESTAMP" "$(date +%s%N | sha256sum | head -c 16)" "$SEVERITY" "$RESULT" "$CORR_ID" \
    "$TOOL" "$OPEN_COUNT" "$TOOL" "$EXIT_CODE" "$DURATION_MS" "$OPEN_COUNT" >> "$LOG_FILE"

echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ $TOOL کامل شد${NC}"
echo -e "${BLUE}⏱️  زمان:${NC}    ${DURATION_MS}ms"
echo -e "${BLUE}📊 Open:${NC}     $OPEN_COUNT"
echo -e "${BLUE}📝 لاگ:${NC}      $LOG_FILE"
echo -e "${BLUE}🔑 Corr ID:${NC}  $CORR_ID"
echo -e "${GREEN}════════════════════════════════════════${NC}"

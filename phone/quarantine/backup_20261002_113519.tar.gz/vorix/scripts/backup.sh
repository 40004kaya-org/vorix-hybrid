#!/bin/bash
# ═══════════════════════════════════════════════
#   VORIX BACKUP SCRIPT
# ═══════════════════════════════════════════════

GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/sdcard/vorix-backups"
BACKUP_NAME="vorix-backup-$TIMESTAMP"
BACKUP_FILE="$BACKUP_DIR/$BACKUP_NAME.tar.gz"

echo -e "${BLUE}💾 VORIX BACKUP${NC}"
echo "════════════════════════════════"

# ۱. ساخت پوشه بک‌آپ
mkdir -p "$BACKUP_DIR"

# ۲. اطلاعات سیستم
echo -e "${BLUE}[1/4]${NC} ذخیره اطلاعات سیستم..."
cat > /tmp/vorix-info.txt << INFO
VORIX Backup
────────────
Date: $(date)
Host: $(hostname)
OS: $(cat /etc/os-release | grep PRETTY_NAME | cut -d'"' -f2)
Kernel: $(uname -r)
g++: $(g++ --version 2>/dev/null | head -1)
nmap: $(nmap --version 2>/dev/null | head -1 | awk '{print $3}')
Python: $(python3 --version 2>/dev/null)
INFO

# ۳. بک‌آپ کامل
echo -e "${BLUE}[2/4]${NC} بک‌آپ فایل‌ها..."

# لیست پوشه‌ها (بدون فایل‌های موقت)
cd ~
tar -czf "$BACKUP_FILE" \
    --exclude='vorix/logs/*.tmp' \
    --exclude='vorix/**/node_modules' \
    --exclude='vorix/**/.cache' \
    vorix/ \
    /tmp/vorix-info.txt 2>/dev/null

# ۴. فشرده‌سازی
echo -e "${BLUE}[3/4]${NC} فشرده‌سازی کامل شد"

# ۵. بررسی نهایی
SIZE=$(du -h "$BACKUP_FILE" | awk '{print $1}')
echo -e "${BLUE}[4/4]${NC} بررسی..."

echo ""
echo -e "${GREEN}════════════════════════════════${NC}"
echo -e "${GREEN}✅ بک‌آپ کامل شد${NC}"
echo -e "${GREEN}════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}📁 فایل:${NC}  $BACKUP_FILE"
echo -e "${YELLOW}📊 حجم:${NC}   $SIZE"
echo -e "${YELLOW}📅 تاریخ:${NC}  $(date)"
echo ""

# لیست بک‌آپ‌های موجود
echo -e "${BLUE}📚 همه بک‌آپ‌ها:${NC}"
ls -lh "$BACKUP_DIR"/*.tar.gz 2>/dev/null | awk '{print "  " $9 " (" $5 ")"}'

# پاک‌کردن بک‌آپ‌های قدیمی (بیشتر از ۱۰)
COUNT=$(ls "$BACKUP_DIR"/*.tar.gz 2>/dev/null | wc -l)
if [ "$COUNT" -gt 10 ]; then
    echo ""
    echo -e "${YELLOW}🧹 حذف بک‌آپ‌های قدیمی (بیش از ۱۰)...${NC}"
    ls -t "$BACKUP_DIR"/*.tar.gz | tail -n +11 | xargs rm -f
fi

echo ""
echo "برای بازگردانی:"
echo "  tar -xzf $BACKUP_FILE -C ~"

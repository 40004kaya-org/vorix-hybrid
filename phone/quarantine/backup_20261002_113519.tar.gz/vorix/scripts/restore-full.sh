#!/data/data/com.termux/files/usr/bin/bash
# VORIX RESTORE

GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

if [ -z "$1" ]; then
    echo "Usage: bash restore-full.sh <backup.tar.gz>"
    echo ""
    echo "بک‌آپ‌های موجود:"
    ls -lh ~/vorix-backups/vorix-full-*.tar.gz 2>/dev/null
    exit 1
fi

BACKUP="$1"

if [ ! -f "$BACKUP" ]; then
    echo -e "${RED}❌ فایل نیست: $BACKUP${NC}"
    exit 1
fi

echo -e "${YELLOW}⚠️  این VORIX فعلی را حذف می‌کند!${NC}"
read -p "ادامه؟ (yes/no): " confirm
if [ "$confirm" != "yes" ]; then
    echo "لغو شد"
    exit 0
fi

# بک‌آپ فعلی قبل از بازگردانی
echo -e "${BLUE}[1/4]${NC} پشتیبان از وضعیت فعلی..."
bash ~/vorix/scripts/backup-full.sh > /dev/null 2>&1

# استخراج
echo -e "${BLUE}[2/4]${NC} استخراج..."
TEMP=$(mktemp -d)
cd "$TEMP"
tar -xzf "$BACKUP"

# پیدا کردن پوشه
FOLDER=$(ls -d */ | head -1)
cd "$FOLDER"

# بازیابی کد
echo -e "${BLUE}[3/4]${NC} بازیابی کدها..."
cd ~
mv vorix vorix-old-$(date +%s)
tar -xzf "$TEMP/$FOLDER/code/vorix-code.tar.gz" -C "$HOME"

# بازیابی لاگ‌ها
mkdir -p ~/vorix/logs/security
cp "$TEMP/$FOLDER/logs/gate09-last1000.jsonl" ~/vorix/logs/security/gate09.jsonl 2>/dev/null

# بازیابی توکن
echo -e "${BLUE}[4/4]${NC} بازیابی کانفیگ..."
if [ -f "$TEMP/$FOLDER/config/credentials.gpg" ]; then
    gpg --decrypt --batch --passphrase "vorix-backup-2026" \
        "$TEMP/$FOLDER/config/credentials.gpg" 2>/dev/null > /tmp/creds.txt
    TOKEN=$(grep -A1 "=== Token ===" /tmp/creds.txt | tail -1)
    if [ -n "$TOKEN" ]; then
        echo "$TOKEN" > ~/vorix/.tg-token
        chmod 600 ~/vorix/.tg-token
    fi
    rm -f /tmp/creds.txt
fi

rm -rf "$TEMP"

echo ""
echo -e "${GREEN}✅ بازگردانی کامل شد${NC}"
echo ""
echo "پوشه قدیمی: vorix-old-*"
echo "برای تست: bash ~/vorix/scripts/backup-full.sh"

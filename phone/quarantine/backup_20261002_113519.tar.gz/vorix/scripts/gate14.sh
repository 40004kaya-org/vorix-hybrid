#!/bin/bash

set -u

VORIX_HOME="$HOME/vorix"
LAB_DIR="/tmp/vorix-gate14-lab"
PORT=18080
LOG_DIR="$VORIX_HOME/logs"
LOG_FILE="$LOG_DIR/gate14.log"

PASS=0
FAIL=0

mkdir -p "$LAB_DIR" "$LOG_DIR"

echo "🧪 VORIX Gate 14 — Test Lab"
echo "══════════════════════════════════════"
echo "🎯 Target: 127.0.0.1:$PORT"
echo ""

printf "gate14-ok\n" > "$LAB_DIR/ok.txt"
printf "gate14-health\n" > "$LAB_DIR/health.txt"

WORDLIST="$LAB_DIR/wordlist.txt"
printf "ok.txt\nhealth.txt\nmissing-page\n" > "$WORDLIST"

python3 -m http.server "$PORT" --bind 127.0.0.1 \
    --directory "$LAB_DIR" >/tmp/vorix-gate14-server.log 2>&1 &
SERVER_PID=$!

cleanup() {
    kill "$SERVER_PID" 2>/dev/null || true
    rm -rf "$LAB_DIR"
}
trap cleanup EXIT

sleep 1

if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "❌ FAIL — Local test server did not start."
    exit 1
fi

echo "🔬 Running VDIRB local test..."
echo ""

OUTPUT="$("$VORIX_HOME/bin/vdirb" \
    "http://127.0.0.1:$PORT" "$WORDLIST" 2>&1)"
STATUS=$?

printf '%s\n' "$OUTPUT"

if [ "$STATUS" -eq 0 ]; then
    PASS=$((PASS + 1))
else
    FAIL=$((FAIL + 1))
fi

if printf '%s\n' "$OUTPUT" | grep -q '\[200\] /ok.txt'; then
    PASS=$((PASS + 1))
else
    FAIL=$((FAIL + 1))
fi

if printf '%s\n' "$OUTPUT" | grep -q '\[200\] /health.txt'; then
    PASS=$((PASS + 1))
else
    FAIL=$((FAIL + 1))
fi

if printf '%s\n' "$OUTPUT" | grep -q '\[404\] /missing-page'; then
    PASS=$((PASS + 1))
else
    FAIL=$((FAIL + 1))
fi

{
    echo "=== VORIX GATE 14 ==="
    echo "Target: 127.0.0.1:$PORT"
    echo "PASS=$PASS FAIL=$FAIL"
    echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
    echo
} >> "$LOG_FILE"

echo ""
echo "══════════════════════════════════════"

if [ "$FAIL" -eq 0 ]; then
    echo "🟢 GATE 14: PASS"
    echo "📝 Audit: $LOG_FILE"
    exit 0
else
    echo "🔴 GATE 14: FAIL"
    echo "📝 Audit: $LOG_FILE"
    exit 1
fi

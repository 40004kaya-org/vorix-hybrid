#!/bin/bash
# ═══════════════════════════════════════════════
#   VORIX GitHub Auto-Push
# ═══════════════════════════════════════════════

GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

cd ~/vorix

echo -e "${BLUE}📤 VORIX → GitHub${NC}"
echo "════════════════════════════════"

CHANGES=$(git status --porcelain | wc -l)

if [ "$CHANGES" -eq 0 ]; then
    echo -e "${YELLOW}⚠️  تغییری نیست${NC}"
    exit 0
fi

echo -e "${BLUE}📝 $CHANGES فایل تغییر کرده:${NC}"
git status --short
echo ""

git add -A
git commit -m "🔐 Auto-backup $(date '+%Y-%m-%d %H:%M')" 2>/dev/null

if git push origin main 2>&1 | grep -qE "main|up-to-date"; then
    echo ""
    echo -e "${GREEN}════════════════════════════════${NC}"
    echo -e "${GREEN}✅ Push موفق به GitHub${NC}"
    echo -e "${GREEN}════════════════════════════════${NC}"
else
    echo -e "${YELLOW}⚠️  خطا در push — دستی چک کن${NC}"
fi

echo ""
echo -e "${BLUE}📊 آخرین commit:${NC}"
git log --oneline -1

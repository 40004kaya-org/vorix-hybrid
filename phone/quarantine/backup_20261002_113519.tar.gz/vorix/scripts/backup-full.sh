#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════
#   VORIX FULL BACKUP
#   پشتیبان‌گیری کامل از پروژه
# ═══════════════════════════════════════════════

GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$HOME/vorix-backups"
BACKUP_NAME="vorix-full-$TIMESTAMP"
BACKUP_PATH="$BACKUP_DIR/$BACKUP_NAME"

echo -e "${BLUE}💾 VORIX FULL BACKUP${NC}"
echo "════════════════════════════════════════"
echo ""

# ۱. ساخت پوشه بک‌آپ
mkdir -p "$BACKUP_DIR"
mkdir -p "$BACKUP_PATH"

# ۲. اطلاعات سیستم
echo -e "${BLUE}[1/7]${NC} اطلاعات سیستم..."
{
    echo "VORIX Backup Report"
    echo "════════════════════════════════════════"
    echo "Date: $(date)"
    echo "Host: $(hostname)"
    echo "User: $(whoami)"
    echo "Home: $HOME"
    echo "Android: $(getprop ro.build.version.release 2>/dev/null || echo 'N/A')"
    echo "Model: $(getprop ro.product.model 2>/dev/null || echo 'N/A')"
    echo ""
    echo "=== Installed Tools ==="
    echo "nmap: $(nmap --version 2>/dev/null | head -1)"
    echo "python: $(python3 --version 2>/dev/null)"
    echo "git: $(git --version 2>/dev/null)"
    echo "curl: $(curl --version 2>/dev/null | head -1)"
    echo ""
    echo "=== VORIX Structure ==="
    find ~/vorix -type f -name "*.py" -o -name "*.sh" -o -name "*.html" -o -name "*.js" 2>/dev/null | sort
} > "$BACKUP_PATH/system-info.txt"
echo -e "${GREEN}✅${NC} system-info.txt"

# ۳. کدها (بدون لاگ‌ها و باینری‌ها)
echo -e "${BLUE}[2/7]${NC} کدهای اصلی..."
mkdir -p "$BACKUP_PATH/code"
cd "$HOME/vorix"

# کپی همه چیز به‌جز فایل‌های بزرگ و لاگ‌ها
tar -czf "$BACKUP_PATH/code/vorix-code.tar.gz" \
    --exclude='logs/security/*.jsonl' \
    --exclude='logs/*.log' \
    --exclude='logs/*.out' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='bin/vscan' \
    --exclude='bin/vbanner' \
    --exclude='bin/vdirb' \
    --exclude='bin/vlog' \
    --exclude='.tg-token' \
    --exclude='wordlists/*.txt' \
    -C "$HOME" vorix/ 2>/dev/null

echo -e "${GREEN}✅${NC} vorix-code.tar.gz ($(du -h "$BACKUP_PATH/code/vorix-code.tar.gz" | awk '{print $1}'))"

# ۴. کانفیگ‌ها (شامل توکن - امن)
echo -e "${BLUE}[3/7]${NC} کانفیگ‌ها (رمزنگاری‌شده)..."
mkdir -p "$BACKUP_PATH/config"

{
    echo "=== Token ==="
    cat ~/vorix/.tg-token 2>/dev/null
    echo ""
    echo "=== Chat ID ==="
    echo "175160049"
    echo ""
    echo "=== Whitelist ==="
    cat ~/vorix/config/whitelist.txt 2>/dev/null
} > "$BACKUP_PATH/config/credentials.txt"

# رمزنگاری کانفیگ
if command -v gpg >/dev/null 2>&1; then
    gpg --symmetric --cipher-algo AES256 \
        --batch --passphrase "vorix-backup-2026" \
        --output "$BACKUP_PATH/config/credentials.gpg" \
        "$BACKUP_PATH/config/credentials.txt" 2>/dev/null && \
        rm "$BACKUP_PATH/config/credentials.txt"
    echo -e "${GREEN}✅${NC} credentials.gpg (رمزنگاری‌شده)"
    echo -e "${YELLOW}   ⚠️ رمز رمزنگاری: vorix-backup-2026${NC}"
else
    echo -e "${YELLOW}⚠️${NC}  gpg نیست — کانفیگ بدون رمزنگاری"
fi

# ۵. لاگ‌ها (آخرین ۱۰۰۰ خط)
echo -e "${BLUE}[4/7]${NC} لاگ‌ها (آخرین ۱۰۰۰ خط)..."
mkdir -p "$BACKUP_PATH/logs"
if [ -f ~/vorix/logs/security/gate09.jsonl ]; then
    tail -1000 ~/vorix/logs/security/gate09.jsonl > "$BACKUP_PATH/logs/gate09-last1000.jsonl" 2>/dev/null
fi
if [ -f ~/vorix/logs/sentinel.log ]; then
    cp ~/vorix/logs/sentinel.log "$BACKUP_PATH/logs/" 2>/dev/null
fi
echo -e "${GREEN}✅${NC} لاگ‌ها"

# ۶. Git Bundle (کل تاریخچه)
echo -e "${BLUE}[5/7]${NC} Git history (bundle)..."
cd ~/vorix
if [ -d .git ]; then
    git bundle create "$BACKUP_PATH/vorix-git.bundle" --all 2>/dev/null
    echo -e "${GREEN}✅${NC} vorix-git.bundle ($(du -h "$BACKUP_PATH/vorix-git.bundle" 2>/dev/null | awk '{print $1}'))"
else
    echo -e "${YELLOW}⚠️${NC}  git نیست"
fi

# ۷. خلاصه ساختار
echo -e "${BLUE}[6/7]${NC} ساختار پوشه‌ها..."
cd ~
find vorix -type f 2>/dev/null | sort > "$BACKUP_PATH/structure.txt"
echo -e "${GREEN}✅${NC} structure.txt"

# ۸. فشرده‌سازی نهایی
echo -e "${BLUE}[7/7]${NC} فشرده‌سازی نهایی..."
cd "$BACKUP_DIR"
FINAL="$BACKUP_DIR/$BACKUP_NAME.tar.gz"
tar -czf "$FINAL" "$BACKUP_NAME/" 2>/dev/null
rm -rf "$BACKUP_NAME/"

SIZE=$(du -h "$FINAL" | awk '{print $1}')

# خلاصه
echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ بک‌آپ کامل شد${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}📁 فایل:${NC}     $FINAL"
echo -e "${BLUE}📊 حجم:${NC}      $SIZE"
echo -e "${BLUE}📅 تاریخ:${NC}     $(date)"
echo -e "${BLUE}🔐 رمز config:${NC} vorix-backup-2026"
echo ""

# حذف بک‌آپ‌های قدیمی (بیشتر از 5)
echo -e "${BLUE}📚 همه بک‌آپ‌ها:${NC}"
ls -lh "$BACKUP_DIR"/vorix-full-*.tar.gz 2>/dev/null | awk '{print "   " $9 " (" $5 ")"}' | tail -10

COUNT=$(ls "$BACKUP_DIR"/vorix-full-*.tar.gz 2>/dev/null | wc -l)
if [ "$COUNT" -gt 5 ]; then
    echo ""
    echo -e "${YELLOW}🧹 حذف بک‌آپ‌های قدیمی (بیشتر از 5)...${NC}"
    ls -t "$BACKUP_DIR"/vorix-full-*.tar.gz | tail -n +6 | xargs rm -f
fi

echo ""
echo -e "${BLUE}🔁 بازگردانی:${NC}"
echo "   bash ~/vorix/scripts/restore-full.sh $FINAL"

#include "../src/logs/security_logger.hpp"

#include <iostream>
#include <map>

int main() {
    using namespace vorix::security;

    SecurityLogger logger("/tmp/vorix-security-test.jsonl");

    LogEvent event{
        Severity::WARN,
        "GATE09",
        "TEST",
        "LOGGER_TEST",
        Result::PASS,
        "",
        "Logger test password=SuperSecret token=HiddenToken",
        {
            {"component", "Gate09"},
            {"password", "DoNotWriteThis"},
            {"status", "healthy"}
        }
    };

    if (!logger.write(event)) {
        std::cerr << "LOGGER_TEST: FAIL\n";
        return 1;
    }

    std::cout << "LOGGER_TEST: PASS\n";
    return 0;
}

#!/usr/bin/env python3
"""
VORIX HONEYPOT — Trap Attackers
سرویس‌های جعلی که هر اتصال به آن‌ها حمله قطعی است
"""
import socket
import threading
import json
import os
import sys
import time
from datetime import datetime

HOME = os.path.expanduser("~")
VORIX = os.path.join(HOME, "vorix")
HONEYPOT_LOG = os.path.join(VORIX, "logs/honeypot.jsonl")
SECURITY_LOG = os.path.join(VORIX, "logs/security/gate09.jsonl")

os.makedirs(os.path.dirname(HONEYPOT_LOG), exist_ok=True)
os.makedirs(os.path.dirname(SECURITY_LOG), exist_ok=True)

R = '\033[0;31m'; G = '\033[0;32m'; Y = '\033[1;33m'
C = '\033[0;36m'; M = '\033[0;35m'; NC = '\033[0m'

# ═══════════════════════════════════════════════
#   HONEYPOTS
# ═══════════════════════════════════════════════

class Honeypot:
    def __init__(self, port, name, banner=""):
        self.port = port
        self.name = name
        self.banner = banner
        self.sock = None
        self.running = False

    def log_hit(self, attacker_ip, data_received):
        """ثبت حمله در دو لاگ"""
        ts = datetime.utcnow().isoformat() + "Z"

        # ۱. لاگ خاص honeypot
        event = {
            "timestamp": ts,
            "honeypot": self.name,
            "port": self.port,
            "attacker_ip": attacker_ip,
            "data": data_received[:500],
            "severity": "CRITICAL",
        }

        with open(HONEYPOT_LOG, "a") as f:
            f.write(json.dumps(event) + "\n")

        # ۲. لاگ امنیتی VORIX
        security_event = {
            "timestamp": ts,
            "severity": "CRITICAL",
            "gate": "GATE01",
            "module": "HONEYPOT",
            "event_type": f"{self.name}_HIT",
            "result": "BLOCK",
            "message": f"🎣 Honeypot triggered: {self.name} on port {self.port} from {attacker_ip}",
            "metadata": {
                "source_ip": attacker_ip,
                "honeypot": self.name,
                "port": str(self.port),
                "data_preview": data_received[:100].replace("\n", " "),
            }
        }

        with open(SECURITY_LOG, "a") as f:
            f.write(json.dumps(security_event) + "\n")

        print(f"{R}🍯 HIT! {self.name} ← {attacker_ip}{NC}")

    def handle_client(self, client_sock, attacker_ip):
        try:
            # ارسال banner جعلی
            if self.banner:
                client_sock.send(self.banner.encode())

            # خواندن داده مهاجم
            client_sock.settimeout(5)
            data = b""
            try:
                while len(data) < 4096:
                    chunk = client_sock.recv(1024)
                    if not chunk:
                        break
                    data += chunk
                    if len(data) > 100:
                        break
            except socket.timeout:
                pass

            if data:
                self.log_hit(attacker_ip, data.decode("utf-8", errors="replace"))
            else:
                # حتی اتصال بدون داده هم ثبت می‌شود
                self.log_hit(attacker_ip, "(connection only)")

        except Exception as e:
            pass
        finally:
            try:
                client_sock.close()
            except:
                pass

    def start(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind(("0.0.0.0", self.port))
            self.sock.listen(10)
            self.running = True

            print(f"{G}✅ {self.name:<15} listening on port {self.port}{NC}")

            while self.running:
                try:
                    self.sock.settimeout(1)
                    client_sock, addr = self.sock.accept()
                    attacker_ip = addr[0]

                    # اجرا در thread جداگانه
                    t = threading.Thread(
                        target=self.handle_client,
                        args=(client_sock, attacker_ip),
                        daemon=True
                    )
                    t.start()

                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        print(f"{Y}⚠️ {self.name}: {e}{NC}")
                    break

        except PermissionError:
            print(f"{R}❌ {self.name}: پورت {self.port} نیاز به root دارد{NC}")
        except OSError as e:
            print(f"{R}❌ {self.name}: {e}{NC}")

    def stop(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except:
                pass


# ═══════════════════════════════════════════════
#   MAIN
# ═══════════════════════════════════════════════
def main():
    print(f"{M}")
    print("╔═══════════════════════════════════════════════╗")
    print("║   🎣 VORIX HONEYPOT SYSTEM                    ║")
    print("║   Trap Attackers — Log Everything            ║")
    print("╚═══════════════════════════════════════════════╝")
    print(f"{NC}")

    # سرویس‌های جعلی
    honeypots = [
        Honeypot(
            port=8888,
            name="HTTP-Admin",
            banner="HTTP/1.1 200 OK\r\nServer: nginx/1.18.0\r\nContent-Type: text/html\r\n\r\n"
                   "<html><head><title>Admin Login</title></head>"
                   "<body><h1>Welcome to Admin Panel</h1>"
                   "<form method='POST' action='/login'>"
                   "Username: <input name='user'><br>"
                   "Password: <input name='pass' type='password'><br>"
                   "<input type='submit' value='Login'>"
                   "</form></body></html>"
        ),
        Honeypot(
            port=2222,
            name="SSH-Fake",
            banner="SSH-2.0-OpenSSH_7.4\r\n"
        ),
        Honeypot(
            port=2121,
            name="FTP-Fake",
            banner="220 Welcome to FTP Server v2.0\r\n"
        ),
    ]

    print(f"{C}🎯 Starting {len(honeypots)} honeypots...{NC}\n")

    # اجرا در thread های جداگانه
    threads = []
    for hp in honeypots:
        t = threading.Thread(target=hp.start, daemon=True)
        t.start()
        threads.append(t)

    print(f"\n{C}📁 Logs:{NC}")
    print(f"   Honeypot: {HONEYPOT_LOG}")
    print(f"   Security: {SECURITY_LOG}")
    print(f"\n{Y}💡 برای تست:{NC}")
    print(f"   curl http://localhost:8888")
    print(f"   nc localhost 2222")
    print(f"\n{R}🛑 برای توقف: Ctrl+C{NC}\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n{Y}⏹ Stopping honeypots...{NC}")
        for hp in honeypots:
            hp.stop()
        print(f"{G}✅ All stopped{NC}")


if __name__ == "__main__":
    main()

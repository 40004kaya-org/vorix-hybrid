#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <netdb.h>

#define GREEN "\033[0;32m"
#define RED "\033[0;31m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[0;34m"
#define CYAN "\033[0;36m"
#define NC "\033[0m"

std::mutex print_mutex;
std::atomic<int> open_count{0};
std::atomic<int> scanned_count{0};

void banner() {
    std::cout << CYAN;
    std::cout << "╔══════════════════════════════════════╗\n";
    std::cout << "║      🔍 VSCAN — Port Scanner 🔍     ║\n";
    std::cout << "║      VORIX Security Tool v1.0        ║\n";
    std::cout << "╚══════════════════════════════════════╝\n";
    std::cout << NC;
}

bool scan_port(const std::string& ip, int port, int timeout_ms = 500) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    fcntl(sock, F_SETFL, O_NONBLOCK);
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, ip.c_str(), &addr.sin_addr);
    int result = connect(sock, (struct sockaddr*)&addr, sizeof(addr));
    if (result < 0 && errno != EINPROGRESS) { close(sock); return false; }
    fd_set fdset;
    FD_ZERO(&fdset);
    FD_SET(sock, &fdset);
    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    result = select(sock + 1, nullptr, &fdset, nullptr, &tv);
    bool is_open = false;
    if (result > 0) {
        int so_error;
        socklen_t len = sizeof(so_error);
        getsockopt(sock, SOL_SOCKET, SO_ERROR, &so_error, &len);
        is_open = (so_error == 0);
    }
    close(sock);
    return is_open;
}

std::string service_name(int port) {
    struct { int port; const char* name; } services[] = {
        {21,"FTP"},{22,"SSH"},{23,"Telnet"},{25,"SMTP"},{53,"DNS"},
        {80,"HTTP"},{110,"POP3"},{143,"IMAP"},{443,"HTTPS"},{445,"SMB"},
        {3306,"MySQL"},{3389,"RDP"},{5432,"PostgreSQL"},{6379,"Redis"},
        {8080,"HTTP-Alt"},{8443,"HTTPS-Alt"},{27017,"MongoDB"},
        {9200,"Elasticsearch"},{5601,"Kibana"},{3000,"Grafana"},
        {8200,"Vault"},{9090,"Prometheus"}
    };
    for (auto& s : services) if (s.port == port) return s.name;
    return "unknown";
}

void worker(const std::string& ip, int start, int end) {
    for (int port = start; port <= end; port++) {
        scanned_count++;
        if (scan_port(ip, port)) {
            std::lock_guard<std::mutex> lock(print_mutex);
            std::cout << GREEN << "  [OPEN] " << NC
                      << "Port " << YELLOW << port << NC
                      << " — " << CYAN << service_name(port) << NC << "\n";
            open_count++;
        }
    }
}

std::string resolve(const std::string& host) {
    struct addrinfo hints, *res;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host.c_str(), nullptr, &hints, &res) != 0) return "";
    char ip[INET_ADDRSTRLEN];
    struct sockaddr_in* addr = (struct sockaddr_in*)res->ai_addr;
    inet_ntop(AF_INET, &addr->sin_addr, ip, sizeof(ip));
    freeaddrinfo(res);
    return std::string(ip);
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        banner();
        std::cout << "Usage: vscan <target> [start] [end]\n";
        std::cout << "Example: vscan 192.168.1.1 1 1000\n";
        return 1;
    }
    std::string target = argv[1];
    int start_port = (argc >= 3) ? std::stoi(argv[2]) : 1;
    int end_port = (argc >= 4) ? std::stoi(argv[3]) : 1024;
    banner();
    std::string ip = resolve(target);
    if (ip.empty()) { std::cerr << RED << "❌ خطا: " << target << NC << "\n"; return 1; }
    std::cout << BLUE << "🎯 Target: " << NC << target;
    if (ip != target) std::cout << " (" << ip << ")";
    std::cout << "\n" << BLUE << "📊 Range:  " << NC << start_port << " - " << end_port << "\n\n";
    auto t_start = std::chrono::high_resolution_clock::now();
    int num_threads = 10;
    int total = end_port - start_port + 1;
    int chunk = total / num_threads;
    if (chunk < 1) chunk = 1;
    std::vector<std::thread> threads;
    for (int i = 0; i < num_threads; i++) {
        int s = start_port + i * chunk;
        int e = (i == num_threads - 1) ? end_port : s + chunk - 1;
        if (s > end_port) break;
        threads.emplace_back(worker, ip, s, e);
    }
    for (auto& t : threads) t.join();
    auto t_end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(t_end - t_start).count();
    std::cout << "\n" << CYAN << "═══════════════════════════════════════\n" << NC;
    std::cout << GREEN << "✅ Open:    " << NC << open_count << " ports\n";
    std::cout << BLUE << "📊 Scanned: " << NC << scanned_count << " ports\n";
    std::cout << BLUE << "⏱️  Time:    " << NC << duration << " ms\n";
    std::cout << CYAN << "═══════════════════════════════════════\n" << NC;
    return 0;
}

#include "security_logger.hpp"

#include <chrono>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <random>
#include <sstream>
#include <string>

namespace vorix::security {

SecurityLogger::SecurityLogger(std::string log_file)
    : log_file_(std::move(log_file)) {}

std::string SecurityLogger::severity_to_string(Severity severity) {
    switch (severity) {
        case Severity::DEBUG:    return "DEBUG";
        case Severity::INFO:     return "INFO";
        case Severity::WARN:     return "WARN";
        case Severity::ERROR:    return "ERROR";
        case Severity::CRITICAL: return "CRITICAL";
    }
    return "UNKNOWN";
}

std::string SecurityLogger::result_to_string(Result result) {
    switch (result) {
        case Result::PASS:    return "PASS";
        case Result::FAIL:    return "FAIL";
        case Result::ALLOW:   return "ALLOW";
        case Result::BLOCK:   return "BLOCK";
        case Result::UNKNOWN: return "UNKNOWN";
    }
    return "UNKNOWN";
}

std::string SecurityLogger::utc_timestamp() {
    const auto now = std::chrono::system_clock::now();
    const std::time_t time = std::chrono::system_clock::to_time_t(now);
    std::tm utc_tm{};
    gmtime_r(&time, &utc_tm);
    std::ostringstream out;
    out << std::put_time(&utc_tm, "%Y-%m-%dT%H:%M:%SZ");
    return out.str();
}

std::string SecurityLogger::generate_event_id() {
    static thread_local std::mt19937_64 rng{std::random_device{}()};
    std::uniform_int_distribution<unsigned long long> dist;
    std::ostringstream out;
    out << "evt-" << std::hex << std::setw(16)
        << std::setfill('0') << dist(rng);
    return out.str();
}

std::string SecurityLogger::generate_correlation_id() {
    static thread_local std::mt19937_64 rng{std::random_device{}()};
    std::uniform_int_distribution<unsigned long long> dist;
    std::ostringstream out;
    out << "corr-" << std::hex << std::setw(16)
        << std::setfill('0') << dist(rng);
    return out.str();
}

std::string SecurityLogger::json_escape(const std::string& value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
            case '\"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\b': out << "\\b";  break;
            case '\f': out << "\\f";  break;
            case '\n': out << "\\n";  break;
            case '\r': out << "\\r";  break;
            case '\t': out << "\\t";  break;
            default:
                if (c < 0x20) {
                    out << "\\u" << std::hex << std::setw(4)
                        << std::setfill('0') << static_cast<int>(c);
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    return out.str();
}

std::string SecurityLogger::redact(const std::string& value) {
    std::string result = value;
    const char* sensitive_keys[] = {
        "password", "passwd", "token", "secret",
        "api_key", "apikey", "private_key", "authorization"
    };
    for (const char* key : sensitive_keys) {
        std::string marker = std::string(key) + "=";
        std::size_t pos = 0;
        while ((pos = result.find(marker, pos)) != std::string::npos) {
            const std::size_t value_start = pos + marker.size();
            const std::size_t end = result.find_first_of(" ,;|", value_start);
            result.replace(
                value_start,
                end == std::string::npos ? std::string::npos
                                         : end - value_start,
                "[REDACTED]"
            );
            pos = value_start + 10;
        }
    }
    return result;
}

static bool is_sensitive_key(const std::string& key) {
    return key == "password" || key == "passwd" ||
           key == "token" || key == "secret" ||
           key == "api_key" || key == "apikey" ||
           key == "private_key" || key == "authorization";
}

bool SecurityLogger::write(const LogEvent& event) {
    std::ofstream file(log_file_, std::ios::app);
    if (!file.is_open()) {
        return false;
    }

    const std::string correlation_id =
        event.correlation_id.empty()
            ? generate_correlation_id()
            : redact(event.correlation_id);

    file << "{"
         << "\"timestamp\":\"" << json_escape(utc_timestamp()) << "\","
         << "\"event_id\":\"" << json_escape(generate_event_id()) << "\","
         << "\"severity\":\""
         << json_escape(severity_to_string(event.severity)) << "\","
         << "\"gate\":\"" << json_escape(redact(event.gate)) << "\","
         << "\"module\":\"" << json_escape(redact(event.module)) << "\","
         << "\"event_type\":\""
         << json_escape(redact(event.event_type)) << "\","
         << "\"result\":\""
         << json_escape(result_to_string(event.result)) << "\","
         << "\"correlation_id\":\""
         << json_escape(correlation_id) << "\","
         << "\"message\":\""
         << json_escape(redact(event.message)) << "\","
         << "\"metadata\":{";

    bool first = true;
    for (const auto& [key, value] : event.metadata) {
        if (!first) {
            file << ",";
        }
        file << "\"" << json_escape(redact(key)) << "\":\""
             << (is_sensitive_key(key) ? "[REDACTED]"
                                       : json_escape(redact(value)))
             << "\"";
        first = false;
    }

    file << "}}\n";
    return true;
}

} // namespace vorix::security

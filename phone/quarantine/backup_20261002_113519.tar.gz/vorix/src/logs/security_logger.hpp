#pragma once

#include <map>
#include <string>

namespace vorix::security {

enum class Severity {
    DEBUG,
    INFO,
    WARN,
    ERROR,
    CRITICAL
};

enum class Result {
    PASS,
    FAIL,
    ALLOW,
    BLOCK,
    UNKNOWN
};

struct LogEvent {
    Severity severity;
    std::string gate;
    std::string module;
    std::string event_type;
    Result result;
    std::string correlation_id;
    std::string message;
    std::map<std::string, std::string> metadata;
};

class SecurityLogger {
public:
    explicit SecurityLogger(std::string log_file);

    bool write(const LogEvent& event);

    static std::string severity_to_string(Severity severity);
    static std::string result_to_string(Result result);

private:
    std::string log_file_;

    static std::string generate_event_id();
    static std::string generate_correlation_id();
    static std::string utc_timestamp();
    static std::string json_escape(const std::string& value);
    static std::string redact(const std::string& value);
};

} // namespace vorix::security

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <chrono>
#include <iomanip>

#define GREEN "\033[0;32m"
#define YELLOW "\033[1;33m"
#define CYAN "\033[0;36m"
#define RED "\033[0;31m"
#define BLUE "\033[0;34m"
#define PURPLE "\033[0;35m"
#define NC "\033[0m"

struct Options {
    std::string log_file = "/tmp/vorix-security-test.jsonl";
    std::string severity_filter;
    std::string gate_filter;
    std::string module_filter;
    std::string result_filter;
    bool stats_only = false;
    bool raw_json = false;
    bool help = false;
};

void print_usage() {
    std::cout << CYAN << "📖 VLOG — VORIX Log Reader\n" << NC;
    std::cout << "═══════════════════════════════════════\n\n";
    std::cout << "Usage: vlog [options]\n\n";
    std::cout << "Options:\n";
    std::cout << "  -f, --file <path>      Log file path\n";
    std::cout << "  -s, --severity <lvl>   Filter by severity (DEBUG/INFO/WARN/ERROR/CRITICAL)\n";
    std::cout << "  -g, --gate <name>      Filter by gate (GATE09)\n";
    std::cout << "  -m, --module <name>    Filter by module\n";
    std::cout << "  -r, --result <type>    Filter by result (PASS/FAIL/ALLOW/BLOCK)\n";
    std::cout << "  --stats                Show statistics only\n";
    std::cout << "  --json                 Raw JSON output\n";
    std::cout << "  -h, --help             Show this help\n\n";
    std::cout << "Examples:\n";
    std::cout << "  vlog --stats\n";
    std::cout << "  vlog --severity=WARN\n";
    std::cout << "  vlog --gate=GATE09 --since=1h\n";
}

Options parse_args(int argc, char* argv[]) {
    Options opt;
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        
        if (arg == "-h" || arg == "--help") opt.help = true;
        else if (arg == "--stats") opt.stats_only = true;
        else if (arg == "--json") opt.raw_json = true;
        else if ((arg == "-f" || arg == "--file") && i+1 < argc) opt.log_file = argv[++i];
        else if ((arg == "-s" || arg == "--severity") && i+1 < argc) opt.severity_filter = argv[++i];
        else if ((arg == "-g" || arg == "--gate") && i+1 < argc) opt.gate_filter = argv[++i];
        else if ((arg == "-m" || arg == "--module") && i+1 < argc) opt.module_filter = argv[++i];
        else if ((arg == "-r" || arg == "--result") && i+1 < argc) opt.result_filter = argv[++i];
        else if (arg.find("--severity=") == 0) opt.severity_filter = arg.substr(11);
        else if (arg.find("--gate=") == 0) opt.gate_filter = arg.substr(7);
        else if (arg.find("--module=") == 0) opt.module_filter = arg.substr(9);
        else if (arg.find("--result=") == 0) opt.result_filter = arg.substr(9);
        else if (arg.find("--file=") == 0) opt.log_file = arg.substr(7);
    }
    return opt;
}

// استخراج مقدار یک فیلد از یک خط JSON ساده
std::string extract_field(const std::string& line, const std::string& field) {
    std::string key = "\"" + field + "\":\"";
    size_t pos = line.find(key);
    if (pos == std::string::npos) return "";
    pos += key.size();
    size_t end = line.find('"', pos);
    if (end == std::string::npos) return "";
    return line.substr(pos, end - pos);
}

std::string color_for_severity(const std::string& sev) {
    if (sev == "CRITICAL") return RED;
    if (sev == "ERROR")    return RED;
    if (sev == "WARN")     return YELLOW;
    if (sev == "INFO")     return GREEN;
    if (sev == "DEBUG")    return BLUE;
    return NC;
}

std::string color_for_result(const std::string& res) {
    if (res == "PASS" || res == "ALLOW") return GREEN;
    if (res == "FAIL" || res == "BLOCK") return RED;
    return NC;
}

int main(int argc, char* argv[]) {
    Options opt = parse_args(argc, argv);
    
    if (opt.help) {
        print_usage();
        return 0;
    }
    
    std::ifstream file(opt.log_file);
    if (!file.is_open()) {
        std::cerr << RED << "❌ Cannot open: " << opt.log_file << NC << "\n";
        std::cerr << "راهنما: vlog --help\n";
        return 1;
    }
    
    if (!opt.raw_json && !opt.stats_only) {
        std::cout << CYAN << "📖 VLOG — خواندن لاگ‌ها\n" << NC;
        std::cout << "═══════════════════════════════════════\n";
        std::cout << "📁 " << opt.log_file << "\n\n";
    }
    
    // آمار
    std::map<std::string, int> sev_count;
    std::map<std::string, int> gate_count;
    std::map<std::string, int> result_count;
    std::map<std::string, int> module_count;
    
    int total = 0;
    int matched = 0;
    std::string line;
    
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        total++;
        
        std::string sev = extract_field(line, "severity");
        std::string gate = extract_field(line, "gate");
        std::string module = extract_field(line, "module");
        std::string result = extract_field(line, "result");
        std::string ts = extract_field(line, "timestamp");
        std::string msg = extract_field(line, "message");
        
        sev_count[sev]++;
        gate_count[gate]++;
        result_count[result]++;
        module_count[module]++;
        
        // فیلترها
        if (!opt.severity_filter.empty() && sev != opt.severity_filter) continue;
        if (!opt.gate_filter.empty() && gate != opt.gate_filter) continue;
        if (!opt.module_filter.empty() && module != opt.module_filter) continue;
        if (!opt.result_filter.empty() && result != opt.result_filter) continue;
        
        matched++;
        
        // نمایش
        if (opt.raw_json) {
            std::cout << line << "\n";
        } else if (!opt.stats_only) {
            std::cout << color_for_severity(sev) << "[" << std::setw(8) << std::left << sev << "]" << NC
                      << " " << CYAN << std::setw(8) << gate << NC
                      << " " << std::setw(20) << ts
                      << " " << color_for_result(result) << result << NC
                      << " " << msg << "\n";
        }
    }
    
    if (opt.stats_only || !opt.raw_json) {
        std::cout << "\n" << CYAN << "═══════════════════════════════════════\n" << NC;
        std::cout << "📊 آمار کلی\n";
        std::cout << "─────────────────────────\n";
        std::cout << "  Total:     " << total << "\n";
        if (matched != total) std::cout << "  Matched:   " << matched << "\n";
        std::cout << "\n";
        
        std::cout << "  By Severity:\n";
        for (const auto& [k, v] : sev_count) {
            std::cout << "    " << color_for_severity(k) << std::setw(10) << std::left << k << NC << ": " << v << "\n";
        }
        std::cout << "\n  By Result:\n";
        for (const auto& [k, v] : result_count) {
            std::cout << "    " << color_for_result(k) << std::setw(10) << std::left << k << NC << ": " << v << "\n";
        }
        std::cout << "\n  By Gate:\n";
        for (const auto& [k, v] : gate_count) {
            std::cout << "    " << std::setw(10) << std::left << k << ": " << v << "\n";
        }
        if (!module_count.empty()) {
            std::cout << "\n  By Module:\n";
            for (const auto& [k, v] : module_count) {
                std::cout << "    " << std::setw(15) << std::left << k << ": " << v << "\n";
            }
        }
    }
    
    return 0;
}

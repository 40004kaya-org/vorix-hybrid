#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>

#define GREEN "\033[0;32m"
#define YELLOW "\033[1;33m"
#define CYAN "\033[0;36m"
#define RED "\033[0;31m"
#define NC "\033[0m"

std::string resolve(const std::string& host) {
    // اگر قبلاً IP است، همان را برگردان
    struct in_addr addr;
    if (inet_pton(AF_INET, host.c_str(), &addr) == 1) return host;
    
    // وگرنه resolve کن
    struct addrinfo hints, *res;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host.c_str(), nullptr, &hints, &res) != 0) return "";
    char ip[INET_ADDRSTRLEN];
    struct sockaddr_in* a = (struct sockaddr_in*)res->ai_addr;
    inet_ntop(AF_INET, &a->sin_addr, ip, sizeof(ip));
    freeaddrinfo(res);
    return std::string(ip);
}

std::string grab(const std::string& ip, int port) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return "";
    
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, ip.c_str(), &addr.sin_addr);
    
    struct timeval tv = {5, 0};
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    
    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        return "";
    }
    
    if (port == 80 || port == 8080 || port == 8000) {
        std::string req = "HEAD / HTTP/1.1\r\nHost: " + ip + "\r\nUser-Agent: VORIX/1.0\r\nConnection: close\r\n\r\n";
        send(sock, req.c_str(), req.size(), 0);
    }
    
    char buf[4096] = {0};
    int n = recv(sock, buf, sizeof(buf) - 1, 0);
    close(sock);
    
    if (n > 0) return std::string(buf, n);
    return "OPEN";
}

int main(int argc, char* argv[]) {
    std::cout << CYAN << "🔍 VBANNER — Service Banner Grabber\n" << NC;
    std::cout << "═══════════════════════════════════════\n\n";
    
    if (argc < 3) {
        std::cout << "Usage: vbanner <host> <port1,port2,...>\n";
        std::cout << "Example: vbanner google.com 80,443\n";
        return 1;
    }
    
    std::string host = argv[1];
    std::string ports = argv[2];
    
    std::string ip = resolve(host);
    if (ip.empty()) {
        std::cerr << RED << "❌ Cannot resolve: " << host << NC << "\n";
        return 1;
    }
    
    std::cout << "🎯 Target: " << host;
    if (ip != host) std::cout << " (" << ip << ")";
    std::cout << "\n\n";
    
    std::stringstream ss(ports);
    std::string port_str;
    int total = 0, found = 0;
    
    while (std::getline(ss, port_str, ',')) {
        int port;
        try { port = std::stoi(port_str); } catch(...) { continue; }
        total++;
        
        std::cout << "🔎 Port " << port << "... ";
        std::cout.flush();
        
        std::string banner = grab(ip, port);
        
        if (banner.empty()) {
            std::cout << RED << "closed/filtered" << NC << "\n";
        } else {
            found++;
            std::cout << GREEN << "OPEN" << NC << "\n";
            if (banner != "OPEN") {
                std::cout << YELLOW << "   ┌─────────────────────────\n" << NC;
                int lines = 0;
                size_t pos = 0, prev = 0;
                while ((pos = banner.find('\n', prev)) != std::string::npos && lines < 6) {
                    std::string line = banner.substr(prev, pos - prev);
                    if (!line.empty() && line.back() == '\r') line.pop_back();
                    if (!line.empty())
                        std::cout << "   │ " << line << "\n";
                    prev = pos + 1;
                    lines++;
                }
                std::cout << YELLOW << "   └─────────────────────────\n" << NC;
            }
        }
    }
    
    std::cout << "\n" << CYAN << "═══════════════════════════════════════\n" << NC;
    std::cout << GREEN << "✅ Open:  " << NC << found << "/" << total << "\n";
    return 0;
}

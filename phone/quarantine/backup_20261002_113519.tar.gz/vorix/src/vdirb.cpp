#include <arpa/inet.h>
#include <chrono>
#include <cctype>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <netdb.h>
#include <sstream>
#include <string>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <vector>

struct Response {
    int status = 0;
    long content_length = -1;
    std::string server = "-";
    double time_ms = 0.0;
    bool error = false;
};

struct Stats {
    int checked = 0;
    int ok = 0;
    int redirects = 0;
    int auth = 0;
    int forbidden = 0;
    int not_found = 0;
    int server_error = 0;
    int other = 0;
    int errors = 0;
};

static bool send_all(int sock, const std::string& data) {
    size_t sent = 0;

    while (sent < data.size()) {
        ssize_t n = send(sock, data.data() + sent,
                         data.size() - sent, 0);

        if (n <= 0)
            return false;

        sent += static_cast<size_t>(n);
    }

    return true;
}

static std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() &&
           std::isspace(static_cast<unsigned char>(s[start]))) {
        ++start;
    }

    size_t end = s.size();
    while (end > start &&
           std::isspace(static_cast<unsigned char>(s[end - 1]))) {
        --end;
    }

    return s.substr(start, end - start);
}

static Response request_head(const std::string& host,
                             int port,
                             const std::string& path) {
    Response result;

    auto start = std::chrono::steady_clock::now();

    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    addrinfo* res = nullptr;

    std::string port_str = std::to_string(port);

    if (getaddrinfo(host.c_str(), port_str.c_str(),
                    &hints, &res) != 0) {
        result.error = true;
        return result;
    }

    int sock = -1;

    for (addrinfo* p = res; p != nullptr; p = p->ai_next) {
        sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol);

        if (sock < 0)
            continue;

        timeval timeout{};
        timeout.tv_sec = 3;
        timeout.tv_usec = 0;

        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO,
                   &timeout, sizeof(timeout));

        setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO,
                   &timeout, sizeof(timeout));

        if (connect(sock, p->ai_addr, p->ai_addrlen) == 0)
            break;

        close(sock);
        sock = -1;
    }

    freeaddrinfo(res);

    if (sock < 0) {
        result.error = true;
        return result;
    }

    if (path.empty() || path[0] != '/') {
        close(sock);
        result.error = true;
        return result;
    }

    std::string request =
        "HEAD " + path + " HTTP/1.1\r\n"
        "Host: " + host + "\r\n"
        "User-Agent: VORIX-VDIRB/3.0\r\n"
        "Connection: close\r\n"
        "\r\n";

    if (!send_all(sock, request)) {
        close(sock);
        result.error = true;
        return result;
    }

    std::string response;
    char buffer[4096];

    while (true) {
        ssize_t n = recv(sock, buffer, sizeof(buffer), 0);

        if (n <= 0)
            break;

        response.append(buffer, static_cast<size_t>(n));

        if (response.size() > 65536)
            break;
    }

    close(sock);

    auto end = std::chrono::steady_clock::now();

    result.time_ms =
        std::chrono::duration<double, std::milli>(end - start).count();

    if (response.empty()) {
        result.error = true;
        return result;
    }

    size_t line_end = response.find("\r\n");

    if (line_end == std::string::npos)
        line_end = response.find('\n');

    std::string status_line =
        response.substr(0, line_end);

    if (status_line.rfind("HTTP/", 0) != 0) {
        result.error = true;
        return result;
    }

    std::istringstream status_stream(status_line);

    std::string protocol;
    status_stream >> protocol;
    status_stream >> result.status;

    if (result.status < 100 || result.status > 599) {
        result.error = true;
        result.status = 0;
        return result;
    }

    size_t pos = 0;

    while (true) {
        size_t next = response.find("\r\n", pos);

        if (next == std::string::npos)
            break;

        if (next == pos)
            break;

        std::string line = response.substr(pos, next - pos);

        size_t colon = line.find(':');

        if (colon != std::string::npos) {
            std::string key = line.substr(0, colon);
            std::string value = trim(line.substr(colon + 1));

            for (char& c : key)
                c = static_cast<char>(
                    std::tolower(static_cast<unsigned char>(c)));

            if (key == "content-length") {
                try {
                    result.content_length = std::stol(value);
                } catch (...) {
                    result.content_length = -1;
                }
            }

            if (key == "server")
                result.server = value;
        }

        pos = next + 2;
    }

    return result;
}

static void print_status(const Response& r,
                         const std::string& path,
                         Stats& stats,
                         std::ofstream& log) {
    stats.checked++;

    std::string label;

    if (r.error) {
        stats.errors++;
        label = "ERROR";
    } else if (r.status == 200) {
        stats.ok++;
        label = "OK";
    } else if (r.status == 301 ||
               r.status == 302 ||
               r.status == 303 ||
               r.status == 307 ||
               r.status == 308) {
        stats.redirects++;
        label = "REDIRECT";
    } else if (r.status == 401) {
        stats.auth++;
        label = "AUTH";
    } else if (r.status == 403) {
        stats.forbidden++;
        label = "FORBIDDEN";
    } else if (r.status == 404) {
        stats.not_found++;
        label = "NOT FOUND";
    } else if (r.status >= 500 && r.status <= 599) {
        stats.server_error++;
        label = "SERVER ERROR";
    } else {
        stats.other++;
        label = "OTHER";
    }

    std::ostringstream line;

    if (r.error) {
        line << "[ERR] " << path;
    } else {
        line << "[" << std::setw(3) << r.status << "] "
             << std::left << std::setw(28) << path
             << " " << std::setw(12) << label
             << " " << std::right
             << std::fixed << std::setprecision(1)
             << std::setw(7) << r.time_ms << " ms";

        if (r.content_length >= 0)
            line << "  " << std::setw(7)
                 << r.content_length << " B";
        else
            line << "  " << std::setw(7) << "-" << " B";

        line << "  Server: " << r.server;
    }

    std::cout << "  " << line.str() << '\n';

    if (log)
        log << line.str() << '\n';
}

int main(int argc, char* argv[]) {
    std::cout
        << "🔍 VDIRB — VORIX HTTP Response Classifier v3.0\n"
        << "══════════════════════════════════════════════\n\n";

    if (argc != 3) {
        std::cout
            << "Usage: vdirb <url> <wordlist>\n"
            << "Example: vdirb http://127.0.0.1:8080 words.txt\n";
        return 1;
    }

    std::string url = argv[1];
    std::string wordlist = argv[2];

    const std::string prefix = "http://";

    if (url.rfind(prefix, 0) != 0) {
        std::cerr
            << "❌ Only HTTP URLs are supported in this version.\n";
        return 1;
    }

    std::string target = url.substr(prefix.size());

    size_t slash = target.find('/');

    if (slash != std::string::npos)
        target = target.substr(0, slash);

    std::string host = target;
    int port = 80;

    size_t colon = host.rfind(':');

    if (colon != std::string::npos) {
        std::string port_part = host.substr(colon + 1);
        host = host.substr(0, colon);

        try {
            port = std::stoi(port_part);
        } catch (...) {
            std::cerr << "❌ Invalid port.\n";
            return 1;
        }
    }

    if (host.empty() || port < 1 || port > 65535) {
        std::cerr << "❌ Invalid target.\n";
        return 1;
    }

    std::ifstream input(wordlist);

    if (!input) {
        std::cerr << "❌ Cannot open wordlist: "
                  << wordlist << '\n';
        return 1;
    }

    std::vector<std::string> paths;
    std::string word;

    while (std::getline(input, word)) {
        word = trim(word);

        if (word.empty())
            continue;

        if (word[0] == '#')
            continue;

        if (word[0] == '/')
            word.erase(0, 1);

        if (!word.empty())
            paths.push_back("/" + word);
    }

    std::cout
        << "🎯 Host:     " << host << '\n'
        << "🔌 Port:     " << port << '\n'
        << "📋 Words:    " << paths.size() << '\n'
        << "📝 Method:   HEAD\n"
        << "⏱️ Timeout:  3 seconds\n\n"
        << "شروع بررسی پاسخ‌ها...\n"
        << "────────────────────────────────────────────────────────────────────\n";

    std::ofstream log("vdirb-report.log", std::ios::app);

    if (log) {
        log << "\n=== VORIX VDIRB 3.0 ===\n";
        log << "Target: http://" << host << ":" << port << '\n';
    }

    Stats stats;

    for (const std::string& path : paths) {
        Response response =
            request_head(host, port, path);

        print_status(response, path, stats, log);
    }

    std::cout
        << "\n════════════════════════════════════════════════════════════════════\n"
        << "📊 VDIRB RESULT\n"
        << "────────────────────────────────────────────────────────────────────\n"
        << "Checked:              " << stats.checked << '\n'
        << "200 OK:               " << stats.ok << '\n'
        << "Redirects:            " << stats.redirects << '\n'
        << "401 Auth Required:    " << stats.auth << '\n'
        << "403 Forbidden:        " << stats.forbidden << '\n'
        << "404 Not Found:        " << stats.not_found << '\n'
        << "5xx Server Error:     " << stats.server_error << '\n'
        << "Other:                " << stats.other << '\n'
        << "Connection/Parse Err: " << stats.errors << '\n'
        << "────────────────────────────────────────────────────────────────────\n";

    if (log)
        log << "Checked=" << stats.checked
            << "  200=" << stats.ok
            << "  Redirects=" << stats.redirects
            << "  401=" << stats.auth
            << "  403=" << stats.forbidden
            << "  404=" << stats.not_found
            << "  5xx=" << stats.server_error
            << "  Other=" << stats.other
            << "  Errors=" << stats.errors << '\n';

    return 0;
}

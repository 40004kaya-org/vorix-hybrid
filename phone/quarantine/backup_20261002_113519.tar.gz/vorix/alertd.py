#!/usr/bin/env python3
"""
VORIX Alert Daemon
پایش لحظه‌ای لاگ‌ها + ارسال هشدار به تلگرام
"""
import json
import os
import time
import sys
import hashlib
from datetime import datetime

try:
    import requests
except ImportError:
    print("❌ نصب کن: pip install requests")
    sys.exit(1)

# ═══════════════════════════════════════════════
#   CONFIGURATION
# ═══════════════════════════════════════════════

HOME = os.path.expanduser("~")

# توکن را از فایل می‌خوانیم
TOKEN_FILE = os.path.join(HOME, "vorix/.tg-token")
try:
    with open(TOKEN_FILE) as f:
        TG_TOKEN = f.read().strip()
except:
    TG_TOKEN = ""

CONFIG = {
    "log_file": os.path.join(HOME, "vorix/logs/security/gate09.jsonl"),
    "alert_log": os.path.join(HOME, "vorix/logs/alerts.log"),
    
    "telegram": {
        "enabled": bool(TG_TOKEN),
        "token": TG_TOKEN,
        "chat_id": "175160049",
    },
    
    "termux_notify": {
        "enabled": True,
    },
    
    "sound": {
        "enabled": True,
        "critical_voice": True,
    },
    
    "rules": {
        "alert_on_severity": ["WARN", "ERROR", "CRITICAL"],
        "alert_on_keywords": [
            "sqli", "sql injection", "attack", "exploit",
            "brute", "blocked", "unauthorized",
            "malware", "backdoor",
        ],
    },
    
    "rate_limit": {
        "same_alert_seconds": 60,
        "max_per_minute": 10,
    },
}

# ═══════════════════════════════════════════════
#   ALERT DAEMON
# ═══════════════════════════════════════════════
class AlertDaemon:
    def __init__(self, config):
        self.config = config
        self.recent_hashes = {}
        self.minute_counter = []
        self.last_pos = 0
        self.log_file = config["log_file"]
        
        os.makedirs(os.path.dirname(config["alert_log"]), exist_ok=True)
    
    def log(self, msg):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {msg}"
        print(line)
        try:
            with open(self.config["alert_log"], "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except:
            pass
    
    def get_file_position(self):
        if not os.path.exists(self.log_file):
            return 0
        return os.path.getsize(self.log_file)
    
    def read_new_lines(self):
        if not os.path.exists(self.log_file):
            return []
        size = os.path.getsize(self.log_file)
        if size < self.last_pos:
            self.last_pos = 0
        if size == self.last_pos:
            return []
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                f.seek(self.last_pos)
                lines = f.readlines()
                self.last_pos = f.tell()
            return [l.strip() for l in lines if l.strip()]
        except Exception as e:
            self.log(f"⚠️ Read error: {e}")
            return []
    
    def should_alert(self, event):
        sev = event.get("severity", "")
        if sev in self.config["rules"]["alert_on_severity"]:
            return True
        msg = (event.get("message", "") + " " + 
               event.get("event_type", "")).lower()
        for kw in self.config["rules"]["alert_on_keywords"]:
            if kw.lower() in msg:
                return True
        return False
    
    def dedup_and_ratelimit(self, event):
        key = f"{event.get('severity')}|{event.get('gate')}|{event.get('event_type')}"
        h = hashlib.md5(key.encode()).hexdigest()[:8]
        now = time.time()
        
        if h in self.recent_hashes:
            if now - self.recent_hashes[h] < self.config["rate_limit"]["same_alert_seconds"]:
                return False
        
        self.minute_counter = [t for t in self.minute_counter if now - t < 60]
        if len(self.minute_counter) >= self.config["rate_limit"]["max_per_minute"]:
            return False
        
        self.recent_hashes[h] = now
        self.minute_counter.append(now)
        return True
    
    def format_message(self, event):
        sev = event.get("severity", "INFO")
        icon = {
            "CRITICAL": "🚨",
            "ERROR": "❌",
            "WARN": "⚠️",
            "INFO": "✅",
            "DEBUG": "🐛"
        }.get(sev, "📝")
        
        ts = event.get("timestamp", "").split("T")[1][:8] if "T" in event.get("timestamp", "") else ""
        
        msg = f"""{icon} VORIX ALERT

Severity: {sev}
Gate: {event.get('gate', 'N/A')}
Module: {event.get('module', 'N/A')}
Event: {event.get('event_type', 'N/A')}
Result: {event.get('result', 'N/A')}
Time: {ts}

Message:
{event.get('message', 'بدون پیام')}"""
        
        meta = event.get("metadata", {})
        if meta:
            msg += "\n\nMetadata:"
            for k, v in list(meta.items())[:5]:
                msg += f"\n  • {k}: {v}"
        
        return msg
    
    def send_telegram(self, msg):
        cfg = self.config["telegram"]
        if not cfg["enabled"] or not cfg["token"]:
            return False
        try:
            url = f"https://api.telegram.org/bot{cfg['token']}/sendMessage"
            r = requests.post(url, json={
                "chat_id": cfg["chat_id"],
                "text": msg,
            }, timeout=10)
            return r.status_code == 200
        except Exception as e:
            self.log(f"⚠️ Telegram error: {e}")
            return False
    
    def send_termux_notification(self, event):
        if not self.config["termux_notify"]["enabled"]:
            return
        try:
            sev = event.get("severity", "INFO")
            title = f"🚨 VORIX {sev}"
            msg = event.get("message", "")[:200]
            os.system(f'termux-notification --title "{title}" --content "{msg}" --priority high 2>/dev/null')
        except:
            pass
    
    def send_sound(self, event):
        if not self.config["sound"]["enabled"]:
            return
        sev = event.get("severity", "")
        try:
            if sev == "CRITICAL":
                os.system('termux-vibrate -d 500 2>/dev/null')
                if self.config["sound"]["critical_voice"]:
                    os.system('termux-tts-speak "Critical security alert" 2>/dev/null')
            elif sev == "ERROR":
                os.system('termux-vibrate -d 200 2>/dev/null')
        except:
            pass
    
    def process_event(self, line):
        try:
            event = json.loads(line)
        except:
            return
        if not self.should_alert(event):
            return
        if not self.dedup_and_ratelimit(event):
            return
        
        msg = self.format_message(event)
        ok_tg = self.send_telegram(msg)
        self.send_termux_notification(event)
        self.send_sound(event)
        
        status = "✅" if ok_tg else "⚠️"
        self.log(f"{status} ALERT: [{event.get('severity')}] {event.get('message', '')[:60]}")
    
    def run(self):
        self.log("=" * 50)
        self.log("🏛️ VORIX Alert Daemon started")
        self.log(f"📁 Watching: {self.log_file}")
        self.log(f"📡 Telegram: {'✅ ON' if self.config['telegram']['enabled'] else '❌ OFF'}")
        self.log("=" * 50)
        
        self.last_pos = self.get_file_position()
        
        while True:
            try:
                lines = self.read_new_lines()
                for line in lines:
                    self.process_event(line)
                time.sleep(1)
            except KeyboardInterrupt:
                self.log("⏹ Daemon stopped")
                sys.exit(0)
            except Exception as e:
                self.log(f"❌ Error: {e}")
                time.sleep(5)

if __name__ == "__main__":
    daemon = AlertDaemon(CONFIG)
    daemon.run()

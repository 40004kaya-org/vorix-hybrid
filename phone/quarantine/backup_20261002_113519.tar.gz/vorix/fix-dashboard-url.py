#!/usr/bin/env python3
"""اضافه کردن URL هوشمند به Sentinel"""

import re, os

path = os.path.expanduser("~/vorix/sentinel.py")
with open(path) as f:
    content = f.read()

# حذف build_buttons قدیمی اگر هست
old_pattern = r'def build_buttons\(ip, event\):.*?return buttons'
new_function = '''def get_dashboard_urls():
    """آدرس‌های داشبورد از منابع مختلف"""
    urls = {}
    
    # ۱. از فایل (اگر Cloudflare کار کرده بود)
    try:
        with open(os.path.expanduser("~/vorix/.public-url")) as f:
            u = f.read().strip()
            if u and u.startswith("http"):
                urls["public"] = u
    except: pass
    
    # ۲. LAN IP
    try:
        import subprocess
        r = subprocess.run(['ifconfig'], capture_output=True, text=True, timeout=3)
        for line in r.stdout.split('\\n'):
            if 'inet ' in line and '127.0.0.1' not in line and '::' not in line:
                ip = line.strip().split()[1]
                urls["lan"] = f"http://{ip}:8000"
                break
    except: pass
    
    # ۳. Localhost (همیشه هست)
    urls["local"] = "http://localhost:8000"
    
    return urls

def build_buttons(ip, event):
    buttons = []
    
    # ردیف ۱: اقدامات IP
    if ip:
        row1 = [
            {"text": "🚫 بلاک IP", "callback_data": f"block_{ip}"},
            {"text": "🔍 اطلاعات IP", "callback_data": f"info_{ip}"},
        ]
        buttons.append(row1)
    
    # ردیف ۲: آمار
    row2 = [
        {"text": "📊 آمار", "callback_data": "stats"},
        {"text": "📋 تاریخچه", "callback_data": "history"},
    ]
    buttons.append(row2)
    
    # ردیف ۳: داشبورد (callback - چون URL localhost رد می‌شود)
    row3 = [
        {"text": "🎛️ باز کردن داشبورد", "callback_data": "open_dashboard"},
    ]
    buttons.append(row3)
    
    return buttons
'''

content = re.sub(old_pattern, new_function, content, count=1, flags=re.DOTALL)

# اضافه کردن handler جدید در handle_commands
old_handler = '''if data == "stats":
                        tg_send(build_stats_message(), cid=cid)
                    elif data == "history":
                        tg_send(build_history_message(), cid=cid)'''

new_handler = '''if data == "stats":
                        tg_send(build_stats_message(), cid=cid)
                    elif data == "history":
                        tg_send(build_history_message(), cid=cid)
                    elif data == "open_dashboard":
                        urls = get_dashboard_urls()
                        text = "🎛️ *VORIX Dashboard*\\n\\n"
                        text += "*روی لینک زیر نگه‌دار → Copy → در مرورگر Paste کن:*\\n\\n"
                        text += f"`{urls['local']}`\\n\\n"
                        if "lan" in urls:
                            text += f"*از دستگاه‌های دیگر روی همان WiFi:*\\n"
                            text += f"`{urls['lan']}`\\n"
                        text += "\\n💡 *نکته:* برای دسترسی فوری، داشبورد را به Home Screen اضافه کن:\\n"
                        text += "مرورگر → localhost:8000 → منو → Add to Home screen"
                        tg_send(text, cid=cid)'''

content = content.replace(old_handler, new_handler, 1)

with open(path, "w") as f:
    f.write(content)

print("✅ Sentinel آپدیت شد")

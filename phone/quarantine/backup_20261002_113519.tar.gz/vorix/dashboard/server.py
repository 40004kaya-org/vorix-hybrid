#!/usr/bin/env python3
"""
VORIX Dashboard Server
اجرای سرور وب + API برای لاگ‌ها
"""
import json
import os
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime

LOG_FILE = os.path.expanduser("~/vorix/logs/security/gate09.jsonl")
PORT = 8000

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        
        # API endpoints
        if parsed.path == '/api/logs':
            self.send_json(self.get_logs())
            return
        
        if parsed.path == '/api/status':
            self.send_json(self.get_status())
            return
        
        if parsed.path == '/api/health':
            self.send_json({"status": "ok", "time": datetime.utcnow().isoformat()})
            return
        
        # Static files
        if parsed.path == '/' or parsed.path == '':
            self.path = '/index.html'
        
        return super().do_GET()
    
    def get_logs(self):
        logs = []
        total = 0
        
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    total += 1
                    try:
                        logs.append(json.loads(line))
                    except:
                        continue
        
        # مرتب‌سازی نزولی بر اساس timestamp
        logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        return {
            "total": total,
            "returned": min(len(logs), 50),
            "logs": logs[:50]
        }
    
    def get_status(self):
        return {
            "status": "healthy",
            "uptime": "running",
            "log_file": LOG_FILE,
            "log_exists": os.path.exists(LOG_FILE)
        }
    
    def send_json(self, data):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))
    
    def log_message(self, format, *args):
        # ساکت کردن لاگ‌های پیش‌فرض
        pass

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    print("╔════════════════════════════════════════════╗")
    print("║  🏛️  VORIX DASHBOARD SERVER               ║")
    print("╚════════════════════════════════════════════╝")
    print(f"")
    print(f"  📁 Directory: {os.getcwd()}")
    print(f"  📝 Log file:  {LOG_FILE}")
    print(f"  🌐 Server:    http://localhost:{PORT}")
    print(f"  📊 API:       http://localhost:{PORT}/api/logs")
    print(f"")
    print(f"  باز کن در مرورگر:")
    print(f"    http://localhost:{PORT}")
    print(f"")
    print(f"  برای توقف: Ctrl+C")
    print(f"")
    
    server = HTTPServer(('0.0.0.0', PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n⏹  Server stopped")
        server.shutdown()

// ═══════════════════════════════════════════════
//   VORIX Dashboard — Frontend Logic
// ═══════════════════════════════════════════════

const API_BASE = 'http://' + window.location.hostname + ':8000';

// ═══ ساعت ═══
function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent = 
        now.toLocaleTimeString('fa-IR');
}
setInterval(updateClock, 1000);
updateClock();

// ═══ رنگ‌ها بر اساس severity ═══
function severityColor(sev) {
    return {
        'CRITICAL': 'text-red-400 bg-red-500/10 border-red-500/30',
        'ERROR':    'text-red-400 bg-red-500/10 border-red-500/30',
        'WARN':     'text-yellow-400 bg-yellow-500/10 border-yellow-500/30',
        'INFO':     'text-green-400 bg-green-500/10 border-green-500/30',
        'DEBUG':    'text-blue-400 bg-blue-500/10 border-blue-500/30'
    }[sev] || 'text-slate-400 bg-slate-500/10 border-slate-500/30';
}

function severityIcon(sev) {
    return {
        'CRITICAL': '🚨',
        'ERROR':    '❌',
        'WARN':     '⚠️',
        'INFO':     '✅',
        'DEBUG':    '🐛'
    }[sev] || '📝';
}

// ═══ رنگ‌ها بر اساس result ═══
function resultColor(res) {
    return {
        'PASS':    'text-green-400',
        'ALLOW':   'text-green-400',
        'FAIL':    'text-red-400',
        'BLOCK':   'text-red-400',
        'UNKNOWN': 'text-slate-400'
    }[res] || 'text-slate-400';
}

// ═══ بارگذاری ابزارها ═══
const TOOLS = [
    { name: 'vscan',      desc: 'Port Scanner (nmap)',      status: 'active' },
    { name: 'vsec-run',   desc: 'Auto-log Wrapper',         status: 'active' },
    { name: 'vbanner',    desc: 'Banner Grabber (Kali)',    status: 'kali'   },
    { name: 'vdirb',      desc: 'Dir Brute-force (Kali)',   status: 'kali'   },
    { name: 'vlog',       desc: 'Log Reader (Kali)',        status: 'kali'   },
    { name: 'vmonitor',   desc: 'Network Monitor',          status: 'planned'},
    { name: 'vhash',      desc: 'Hash Tool',                status: 'planned'}
];

function renderTools() {
    const container = document.getElementById('toolsList');
    container.innerHTML = TOOLS.map(t => {
        const colors = {
            active:  'text-green-400 bg-green-500/10',
            kali:    'text-yellow-400 bg-yellow-500/10',
            planned: 'text-slate-500 bg-slate-500/10'
        }[t.status];
        
        const icon = {
            active:  '✅',
            kali:    '⏸',
            planned: '⏳'
        }[t.status];
        
        return `
            <div class="flex items-center justify-between p-2.5 bg-slate-900/50 rounded-lg border border-slate-700/50">
                <div class="flex items-center gap-3">
                    <span class="text-lg">${icon}</span>
                    <div>
                        <p class="text-sm font-mono font-bold">${t.name}</p>
                        <p class="text-[10px] text-slate-500">${t.desc}</p>
                    </div>
                </div>
                <span class="badge ${colors}">${t.status}</span>
            </div>
        `;
    }).join('');
}

// ═══ بارگذاری Gate ها ═══
const GATES = [
    { id: '00', name: 'Threat Modeling',    on: false },
    { id: '01', name: 'Network Security',   on: true  },
    { id: '02', name: 'Identity + MFA',     on: false },
    { id: '03', name: 'Authorization',      on: false },
    { id: '04', name: 'Traffic Control',    on: false },
    { id: '05', name: 'Behavior Monitor',   on: false },
    { id: '06', name: 'Service Protection', on: false },
    { id: '07', name: 'Data Protection',    on: true  },
    { id: '08', name: 'Data Vault',         on: false },
    { id: '09', name: 'Security Log',       on: true  },
    { id: '10', name: 'Alert Center',       on: false },
    { id: '11', name: 'Incident Case',      on: false },
    { id: '12', name: 'AI Analysis',        on: false },
    { id: '13', name: 'Repair Proposal',    on: false },
    { id: '14', name: 'Test Lab',           on: false }
];

function renderGates() {
    const container = document.getElementById('gatesList');
    container.innerHTML = GATES.map(g => {
        const color = g.on ? 'text-green-400' : 'text-slate-500';
        const dot = g.on ? '●' : '○';
        return `
            <div class="flex items-center justify-between p-2 rounded-lg hover:bg-slate-900/50 transition">
                <div class="flex items-center gap-2">
                    <span class="${color} font-bold">${dot}</span>
                    <span class="text-[10px] text-slate-500 font-mono">Gate ${g.id}</span>
                    <span class="text-xs">${g.name}</span>
                </div>
                <span class="badge ${g.on ? 'bg-green-500/10 text-green-400' : 'bg-slate-500/10 text-slate-500'}">
                    ${g.on ? 'ON' : 'OFF'}
                </span>
            </div>
        `;
    }).join('');
}

// ═══ بارگذاری رویدادها ═══
async function loadEvents() {
    try {
        const res = await fetch(API_BASE + '/api/logs?limit=50');
        if (!res.ok) throw new Error('API offline');
        const data = await res.json();
        
        document.getElementById('totalEvents').textContent = data.total || 0;
        
        let warn = 0, crit = 0;
        data.logs.forEach(l => {
            if (l.severity === 'WARN' || l.severity === 'ERROR') warn++;
            if (l.severity === 'CRITICAL') crit++;
        });
        
        document.getElementById('warningCount').textContent = warn;
        document.getElementById('criticalCount').textContent = crit;
        
        renderEvents(data.logs);
        updateCharts(data.logs);
        
    } catch (err) {
        console.warn('API error:', err.message);
        renderEventsDemo();
    }
}

function renderEvents(logs) {
    const container = document.getElementById('eventsList');
    
    if (!logs || logs.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-slate-500">
                <p class="text-sm">📭 هنوز رویدادی نیست</p>
                <p class="text-[10px] mt-2">vsec-run vscan ... اجرا کن</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = logs.slice(0, 30).map(l => {
        const time = l.timestamp ? l.timestamp.substr(11, 8) : '--:--:--';
        return `
            <div class="event-row flex items-center gap-3 p-2.5 rounded-lg">
                <span class="text-[10px] text-slate-500 font-mono w-14">${time}</span>
                <span class="badge ${severityColor(l.severity)}">
                    ${severityIcon(l.severity)} ${l.severity}
                </span>
                <span class="text-[10px] text-slate-500 font-mono">${l.gate || '---'}</span>
                <span class="text-xs ${resultColor(l.result)} font-bold">${l.result || '?'}</span>
                <span class="text-xs text-slate-300 truncate flex-1">${l.message || ''}</span>
            </div>
        `;
    }).join('');
}

// ═══ رویدادهای نمایشی (اگر API نبود) ═══
function renderEventsDemo() {
    const demo = [
        { timestamp: new Date().toISOString(), severity: 'INFO', gate: 'GATE01', result: 'PASS', message: 'Starting vscan scanme.nmap.org' },
        { timestamp: new Date(Date.now()-5000).toISOString(), severity: 'INFO', gate: 'GATE01', result: 'PASS', message: 'vscan finished: 2 open' },
        { timestamp: new Date(Date.now()-30000).toISOString(), severity: 'WARN', gate: 'GATE05', result: 'FAIL', message: 'Weak TLS cipher detected' },
        { timestamp: new Date(Date.now()-60000).toISOString(), severity: 'CRITICAL', gate: 'GATE01', result: 'BLOCK', message: 'SQL Injection blocked from 45.33.32.156' },
        { timestamp: new Date(Date.now()-90000).toISOString(), severity: 'INFO', gate: 'GATE02', result: 'PASS', message: 'User admin logged in' }
    ];
    document.getElementById('totalEvents').textContent = demo.length;
    document.getElementById('warningCount').textContent = '2';
    document.getElementById('criticalCount').textContent = '1';
    renderEvents(demo);
    updateCharts(demo);
}

// ═══ نمودارها ═══
let severityChart, timelineChart;

function updateCharts(logs) {
    const counts = { CRITICAL: 0, ERROR: 0, WARN: 0, INFO: 0, DEBUG: 0 };
    logs.forEach(l => { if (counts[l.severity] !== undefined) counts[l.severity]++; });
    
    // Severity Chart
    const ctx1 = document.getElementById('severityChart').getContext('2d');
    if (severityChart) severityChart.destroy();
    severityChart = new Chart(ctx1, {
        type: 'doughnut',
        data: {
            labels: ['CRITICAL', 'ERROR', 'WARN', 'INFO', 'DEBUG'],
            datasets: [{
                data: [counts.CRITICAL, counts.ERROR, counts.WARN, counts.INFO, counts.DEBUG],
                backgroundColor: ['#ef4444', '#dc2626', '#facc15', '#22c55e', '#3b82f6'],
                borderColor: '#0a0e1a',
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#94a3b8', font: { size: 11 }, padding: 10 }
                }
            },
            cutout: '65%'
        }
    });
    
    // Timeline Chart
    const buckets = {};
    logs.forEach(l => {
        const h = l.timestamp ? l.timestamp.substr(11, 2) : '00';
        buckets[h] = (buckets[h] || 0) + 1;
    });
    const labels = Object.keys(buckets).sort();
    
    const ctx2 = document.getElementById('timelineChart').getContext('2d');
    if (timelineChart) timelineChart.destroy();
    timelineChart = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: labels.length ? labels : ['0'],
            datasets: [{
                label: 'Events',
                data: labels.map(h => buckets[h]),
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59,130,246,0.15)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#3b82f6',
                pointBorderColor: '#0a0e1a',
                pointBorderWidth: 2,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: {
                    grid: { color: 'rgba(51,65,85,0.2)' },
                    ticks: { color: '#94a3b8' },
                    beginAtZero: true
                },
                x: {
                    grid: { display: false },
                    ticks: { color: '#94a3b8' }
                }
            }
        }
    });
}

// ═══ شروع ═══
renderTools();
renderGates();
loadEvents();
setInterval(loadEvents, 5000);

console.log('🏛️ VORIX Dashboard loaded');
console.log('📡 API:', API_BASE);

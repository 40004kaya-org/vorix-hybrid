#!/usr/bin/env python3
"""
🛡️ VORIX SENTINEL — Advanced Threat Detection System
Real-time attack detection with smart alerting
"""
import json, os, time, sys, hashlib, re
import requests
from datetime import datetime, timedelta
from collections import defaultdict

# ═══════════════════════════════════════════════
#   CONFIG
# ═══════════════════════════════════════════════
HOME = os.path.expanduser("~")
VORIX = os.path.join(HOME, "vorix")
LOG_FILE = os.path.join(VORIX, "logs/security/gate09.jsonl")
STATS_FILE = os.path.join(VORIX, "logs/stats.json")
WHITELIST_FILE = os.path.join(VORIX, "config/whitelist.txt")
ALERTS_LOG = os.path.join(VORIX, "logs/sentinel.log")

# توکن
with open(os.path.join(VORIX, ".tg-token")) as f:
    TOKEN = f.read().strip()
CHAT_ID = "175160049"

os.makedirs(os.path.dirname(WHITELIST_FILE), exist_ok=True)

# ═══════════════════════════════════════════════
#   THREAT INTELLIGENCE
# ═══════════════════════════════════════════════
ATTACK_TYPES = {
    "SQL Injection":     {"score": 90, "emoji": "💉", "kw": ["sqli","sql injection","' or ","union select"]},
    "XSS":               {"score": 70, "emoji": "🎯", "kw": ["xss","<script","javascript:"]},
    "Brute Force":       {"score": 80, "emoji": "🔨", "kw": ["brute","bruteforce","login fail","auth fail","failed password"]},
    "DDoS":              {"score": 95, "emoji": "🌊", "kw": ["ddos","flood","overload","rate limit exceeded"]},
    "Port Scan":         {"score": 50, "emoji": "🔍", "kw": ["port scan","nmap","scan detected"]},
    "Malware":           {"score": 100,"emoji": "☠️", "kw": ["malware","virus","trojan","ransom"]},
    "Backdoor":          {"score": 100,"emoji": "🚪", "kw": ["backdoor","shell","reverse shell"]},
    "Privilege Escalation": {"score": 95, "emoji": "⬆️","kw": ["privilege","escalat","sudo exploit"]},
    "Data Exfiltration": {"score": 100,"emoji": "📤", "kw": ["exfil","data leak","stolen"]},
    "Phishing":          {"score": 60, "emoji": "🎣", "kw": ["phish","credential"]},
    "Reconnaissance":    {"score": 40, "emoji": "🔎", "kw": ["recon","whois","dns enum"]},
    "Exploit Attempt":   {"score": 85, "emoji": "⚡", "kw": ["exploit","cve-","vulnerability"]},
    "Unauthorized Access":{"score": 90, "emoji":"🚫", "kw": ["unauthorized","forbidden","access denied"]},
    "Anomaly":           {"score": 50, "emoji": "❓", "kw": ["anomaly","unusual"]},
}

SEVERITY_SCORES = {
    "CRITICAL": 100,
    "ERROR": 75,
    "WARN": 50,
    "INFO": 20,
    "DEBUG": 5,
}

# ═══════════════════════════════════════════════
#   STATE
# ═══════════════════════════════════════════════
class State:
    def __init__(self):
        self.recent_hashes = {}
        self.minute_counter = []
        self.stats = self.load_stats()
        self.whitelist = self.load_whitelist()
        self.blocked_ips = set()
        self.alert_history = []

    def load_stats(self):
        if os.path.exists(STATS_FILE):
            try:
                with open(STATS_FILE) as f:
                    return json.load(f)
            except: pass
        return {
            "total_alerts": 0,
            "critical": 0,
            "attacks_by_type": {},
            "attacks_by_ip": {},
            "attacks_by_hour": {},
            "first_seen": datetime.utcnow().isoformat(),
            "last_alert": None,
        }

    def save_stats(self):
        try:
            with open(STATS_FILE, "w") as f:
                json.dump(self.stats, f, indent=2)
        except: pass

    def load_whitelist(self):
        if not os.path.exists(WHITELIST_FILE):
            # ایجاد با مقادیر پیش‌فرض
            with open(WHITELIST_FILE, "w") as f:
                f.write("# VORIX Whitelist - IPs امن\n")
                f.write("# هر IP در یک خط\n")
                f.write("127.0.0.1\n")
                f.write("localhost\n")
            return {"127.0.0.1", "localhost"}
        with open(WHITELIST_FILE) as f:
            return {l.strip() for l in f if l.strip() and not l.startswith("#")}

STATE = State()

# ═══════════════════════════════════════════════
#   HELPERS
# ═══════════════════════════════════════════════
def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    try:
        with open(ALERTS_LOG, "a") as f:
            f.write(line + "\n")
    except: pass

def tg_send(text, keyboard=None, cid=None):
    payload = {
        "chat_id": cid or CHAT_ID,
        "text": text,
        
        "disable_web_page_preview": True,
    }
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{TOKEN}/sendMessage",
            json=payload, timeout=10
        )
        return r.json()
    except Exception as e:
        log(f"TG error: {e}")
        return {}

def classify_attack(event):
    """تشخیص نوع حمله"""
    text = (event.get("message","") + " " + event.get("event_type","")).lower()
    for attack, info in ATTACK_TYPES.items():
        for kw in info["kw"]:
            if kw in text:
                return attack, info
    return "Unknown", {"score": 30, "emoji": "❓", "kw": []}

def extract_ip(event):
    """استخراج IP از رویداد"""
    # جستجو در metadata
    meta = event.get("metadata", {})
    for key in ["ip", "source_ip", "src_ip", "client_ip", "attacker"]:
        if key in meta:
            val = str(meta[key])
            if re.match(r"^\d+\.\d+\.\d+\.\d+$", val):
                return val
    # جستجو در message
    m = re.search(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", event.get("message",""))
    if m:
        return m.group(1)
    return None

def is_whitelisted(ip):
    if not ip: return False
    return ip in STATE.whitelist or ip.startswith("192.168.") or ip.startswith("10.")

def get_geoip(ip):
    """گرفتن اطلاعات جغرافیایی IP"""
    if not ip:
        return None
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}?fields=status,country,city,isp,org,as,query",
                        timeout=5)
        d = r.json()
        if d.get("status") == "success":
            return d
    except: pass
    return None

def threat_score(event):
    """محاسبه امتیاز تهدید (0-100)"""
    sev_score = SEVERITY_SCORES.get(event.get("severity","INFO"), 20)
    attack, info = classify_attack(event)
    attack_score = info["score"]

    # امتیاز ترکیبی
    score = int((sev_score * 0.5) + (attack_score * 0.5))

    # بونوس
    if "blocked" in event.get("message","").lower():
        score = min(100, score + 10)
    if "attack" in event.get("message","").lower():
        score = min(100, score + 5)

    return min(100, score), attack, info

def score_emoji(score):
    if score >= 90: return "🔴🔴🔴"
    if score >= 70: return "🔴🔴"
    if score >= 50: return "🟠"
    if score >= 30: return "🟡"
    return "🟢"

def is_night():
    """حالت شب (00:00 - 06:00)"""
    hour = datetime.now().hour
    return 0 <= hour < 6

# ═══════════════════════════════════════════════
#   ALERT BUILDER
# ═══════════════════════════════════════════════
def build_alert(event):
    """ساخت پیام هشدار زیبا"""
    score, attack, info = threat_score(event)
    ip = extract_ip(event)
    geo = get_geoip(ip) if ip else None

    sev = event.get("severity", "INFO")
    ts = event.get("timestamp", "").split("T")[1][:8] if "T" in event.get("timestamp","") else datetime.now().strftime("%H:%M:%S")

    # سرتیتر
    if sev == "CRITICAL":
        header = "🚨 *CRITICAL SECURITY ALERT* 🚨"
    elif sev == "ERROR":
        header = "❌ *Security Error Detected*"
    elif sev == "WARN":
        header = "⚠️ *Security Warning*"
    else:
        header = "ℹ️ *Security Event*"

    msg = f"{header}\n"
    msg += f"`━━━━━━━━━━━━━━━━━━━━━━━━━━━━`\n\n"

    # امتیاز تهدید
    sev_emoji = score_emoji(score)
    msg += f"*🎯 Threat Score:* {sev_emoji} `{score}/100`\n"
    msg += f"*🎭 Attack Type:* {info['emoji']} `{attack}`\n"
    msg += f"*⚡ Severity:* `{sev}`\n\n"

    # اطلاعات حمله
    msg += f"*📍 Gate:* `{event.get('gate','N/A')}`\n"
    msg += f"*🔧 Module:* `{event.get('module','N/A')}`\n"
    msg += f"*⚙️ Event:* `{event.get('event_type','N/A')}`\n"
    msg += f"*✅ Result:* `{event.get('result','N/A')}`\n"
    msg += f"*🕐 Time:* `{ts}`\n\n"

    # IP و موقعیت
    if ip:
        msg += f"*🌐 Source IP:* `{ip}`\n"
        if geo:
            country = geo.get("country","?")
            city = geo.get("city","?")
            isp = geo.get("isp","?")
            flag = get_flag(country)
            msg += f"*{flag} Location:* `{city}, {country}`\n"
            msg += f"*🏢 ISP:* `{isp[:30]}`\n"
        msg += "\n"

    # پیام اصلی
    msg += f"*📝 Details:*\n"
    msg += f"```\n{event.get('message','')[:250]}\n```\n"

    # متادیتا اضافه
    meta = event.get("metadata", {})
    if meta:
        msg += f"\n*📎 Extra Info:*\n"
        for k, v in list(meta.items())[:4]:
            msg += f"  • `{k}`: `{str(v)[:40]}`\n"

    # هشدار شب
    if is_night():
        msg += f"\n🌙 *Night Mode Active*"

    return msg, score, ip, attack

def get_flag(country):
    """پرچم کشور"""
    flags = {
        "Iran": "🇮🇷", "United States": "🇺🇸", "Russia": "🇷🇺",
        "China": "🇨🇳", "Germany": "🇩🇪", "France": "🇫🇷",
        "United Kingdom": "🇬🇧", "Netherlands": "🇳🇱",
        "India": "🇮🇳", "Turkey": "🇹🇷", "Israel": "🇮🇱",
        "Ukraine": "🇺🇦", "Poland": "🇵🇱", "Brazil": "🇧🇷",
    }
    return flags.get(country, "🌐")

def build_buttons(ip, event):
    """دکمه‌های اقدام"""
    buttons = []
    row1 = []
    if ip:
        row1.append({"text": "🚫 بلاک IP", "callback_data": f"block_{ip}"})
        row1.append({"text": "🔍 اطلاعات IP", "callback_data": f"info_{ip}"})
    if row1:
        buttons.append(row1)

    row2 = [
        {"text": "📊 آمار", "callback_data": "stats"},
        {"text": "📋 تاریخچه", "callback_data": "history"},
    ]
    buttons.append(row2)

    row3 = [
        
    ]
    buttons.append(row3)

    return buttons

# ═══════════════════════════════════════════════
#   RATE LIMIT
# ═══════════════════════════════════════════════
def should_alert(event, score):
    """آیا هشدار بفرستیم؟"""
    # Whitelist
    ip = extract_ip(event)
    if is_whitelisted(ip):
        return False

    # امتیاز پایین + روز → نادیده
    if score < 30 and not is_night():
        return False

    # تکرار
    key = f"{event.get('severity')}|{event.get('gate')}|{event.get('event_type')}"
    h = hashlib.md5(key.encode()).hexdigest()[:8]
    now = time.time()

    # در شب: اجازه تکرار بیشتر
    cooldown = 30 if is_night() else 60
    if h in STATE.recent_hashes and now - STATE.recent_hashes[h] < cooldown:
        return False

    # سقف دقیقه‌ای
    STATE.minute_counter = [t for t in STATE.minute_counter if now - t < 60]
    if len(STATE.minute_counter) >= (15 if is_night() else 10):
        return False

    STATE.recent_hashes[h] = now
    STATE.minute_counter.append(now)
    return True

# ═══════════════════════════════════════════════
#   STATS
# ═══════════════════════════════════════════════
def update_stats(event, score, ip, attack):
    STATE.stats["total_alerts"] += 1
    if event.get("severity") == "CRITICAL":
        STATE.stats["critical"] += 1

    STATE.stats["attacks_by_type"][attack] = STATE.stats["attacks_by_type"].get(attack, 0) + 1

    if ip:
        STATE.stats["attacks_by_ip"][ip] = STATE.stats["attacks_by_ip"].get(ip, 0) + 1

    hour = datetime.now().strftime("%H")
    STATE.stats["attacks_by_hour"][hour] = STATE.stats["attacks_by_hour"].get(hour, 0) + 1

    STATE.stats["last_alert"] = datetime.utcnow().isoformat()
    STATE.save_stats()

def build_stats_message():
    s = STATE.stats
    msg = "📊 *VORIX Statistics*\n"
    msg += "`━━━━━━━━━━━━━━━━━━━━━━━━━━━━`\n\n"
    msg += f"*📈 Total Alerts:* `{s['total_alerts']}`\n"
    msg += f"*🚨 Critical:* `{s['critical']}`\n"
    msg += f"*🕐 Last Alert:* `{(s.get('last_alert','N/A') or 'N/A')[:19]}`\n\n"

    if s["attacks_by_type"]:
        msg += "*🎭 Attacks by Type:*\n"
        sorted_types = sorted(s["attacks_by_type"].items(), key=lambda x: -x[1])[:5]
        for atype, count in sorted_types:
            emoji = ATTACK_TYPES.get(atype, {}).get("emoji", "❓")
            msg += f"  {emoji} `{atype}`: *{count}*\n"

    if s["attacks_by_ip"]:
        msg += "\n*🌐 Top Attackers:*\n"
        sorted_ips = sorted(s["attacks_by_ip"].items(), key=lambda x: -x[1])[:5]
        for ip, count in sorted_ips:
            msg += f"  • `{ip}`: *{count}*\n"

    return msg

def build_history_message():
    msg = "📋 *Recent Alerts (Last 10)*\n"
    msg += "`━━━━━━━━━━━━━━━━━━━━━━━━━━━━`\n\n"
    for h in STATE.alert_history[-10:][::-1]:
        msg += f"{h['emoji']} `{h['time']}` *{h['severity']}*\n"
        msg += f"   {h['message'][:50]}\n\n"
    if not STATE.alert_history:
        msg += "_(خالی)_"
    return msg

# ═══════════════════════════════════════════════
#   WATCHER
# ═══════════════════════════════════════════════
def watch_logs():
    if not os.path.exists(LOG_FILE):
        return
    last_pos = os.path.getsize(LOG_FILE)

    log(f"👁️ Watching: {LOG_FILE}")
    log(f"🤖 Ready")

    while True:
        try:
            if not os.path.exists(LOG_FILE):
                time.sleep(2); continue

            size = os.path.getsize(LOG_FILE)
            if size < last_pos: last_pos = 0
            if size == last_pos:
                time.sleep(1); continue

            with open(LOG_FILE) as f:
                f.seek(last_pos)
                lines = f.readlines()
                last_pos = f.tell()

            for line in lines:
                line = line.strip()
                if not line: continue
                try: event = json.loads(line)
                except: continue

                # محاسبه امتیاز
                score, attack, info = threat_score(event)

                # بررسی هشدار
                if not should_alert(event, score):
                    continue

                # ساخت و ارسال
                msg, score, ip, attack = build_alert(event)
                buttons = build_buttons(ip, event)

                tg_send(msg, buttons)

                # Notification
                sev = event.get("severity", "INFO")
                title = f"{info['emoji']} VORIX {sev}"
                content = event.get("message", "")[:150]
                os.system(f'termux-notification --title "{title}" --content "{content}" --priority high --button1 "Dashboard" --button1-action "termux-open-url http://localhost:8000" 2>/dev/null')

                # صدا
                if sev == "CRITICAL" or score >= 80:
                    os.system('termux-vibrate -d 500 2>/dev/null')
                    os.system('termux-tts-speak "Critical alert" 2>/dev/null')
                elif sev == "ERROR":
                    os.system('termux-vibrate -d 200 2>/dev/null')

                # آمار
                update_stats(event, score, ip, attack)
                STATE.alert_history.append({
                    "time": datetime.now().strftime("%H:%M:%S"),
                    "severity": sev,
                    "message": event.get("message", ""),
                    "score": score,
                    "emoji": info["emoji"],
                    "attack": attack,
                })

                log(f"✅ Alert sent: [{sev}] score={score} {attack} - {event.get('message','')[:40]}")

        except KeyboardInterrupt:
            log("⏹ Bye")
            sys.exit(0)
        except Exception as e:
            log(f"⚠️ {e}")
            time.sleep(3)

# ═══════════════════════════════════════════════
#   COMMAND HANDLER (اختیاری - اگر bot.py نبود)
# ═══════════════════════════════════════════════
def handle_commands():
    """پردازش دستورات تلگرام"""
    offset = None
    while True:
        try:
            r = requests.get(
                f"https://api.telegram.org/bot{TOKEN}/getUpdates",
                params={"timeout": 25, "offset": offset} if offset else {"timeout": 25},
                timeout=30
            ).json()

            if not r.get("ok"):
                time.sleep(3); continue

            for up in r.get("result", []):
                offset = up["update_id"] + 1
                msg = up.get("message", {})
                txt = msg.get("text", "")
                cid = msg.get("chat", {}).get("id")

                if txt == "/stats":
                    tg_send(build_stats_message(), cid=cid)
                elif txt == "/history":
                    tg_send(build_history_message(), cid=cid)
                elif txt == "/start":
                    tg_send(
                        "🛡️ *VORIX SENTINEL*\n\n"
                        "سیستم هشدار پیشرفته امنیتی\n\n"
                        "*دستورها:*\n"
                        "/stats — آمار\n"
                        "/history — تاریخچه\n"
                        "/help — راهنما",
                        cid=cid
                    )

                # Callback queries (دکمه‌ها)
                cb = up.get("callback_query")
                if cb:
                    data = cb.get("data","")
                    cid = cb.get("message",{}).get("chat",{}).get("id")
                    if data == "stats":
                        tg_send(build_stats_message(), cid=cid)
                    elif data == "history":
                        tg_send(build_history_message(), cid=cid)
                    elif data.startswith("info_"):
                        ip = data.replace("info_","")
                        geo = get_geoip(ip)
                        if geo:
                            text = f"🔍 *IP Info: {ip}*\n\n"
                            text += f"🌍 Country: `{geo.get('country')}`\n"
                            text += f"🏙️ City: `{geo.get('city')}`\n"
                            text += f"🏢 ISP: `{geo.get('isp')}`\n"
                            tg_send(text, cid=cid)
                    elif data.startswith("block_"):
                        ip = data.replace("block_","")
                        STATE.blocked_ips.add(ip)
                        with open(WHITELIST_FILE, "a") as f:
                            f.write(f"# BLOCKED: {ip}\n")
                        tg_send(f"🚫 IP `{ip}` در لیست سیاه ثبت شد", cid=cid)

        except Exception as e:
            time.sleep(3)

# ═══════════════════════════════════════════════
#   MAIN
# ═══════════════════════════════════════════════
def main():
    print("╔════════════════════════════════════════════╗")
    print("║   🛡️  VORIX SENTINEL                       ║")
    print("║   Advanced Threat Detection System         ║")
    print("╚════════════════════════════════════════════╝")
    print()
    print(f"📁 Log file: {LOG_FILE}")
    print(f"📊 Stats: {STATS_FILE}")
    print(f"🚫 Whitelist: {WHITELIST_FILE}")
    print(f"🌙 Night mode: {'ON' if is_night() else 'OFF'}")
    print()

    # اجرای watcher در thread
    import threading
    t = threading.Thread(target=watch_logs, daemon=True)
    t.start()

    # اجرای command handler در thread اصلی
    handle_commands()

if __name__ == "__main__":
    main()

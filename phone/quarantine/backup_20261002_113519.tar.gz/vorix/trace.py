#!/usr/bin/env python3
"""
VORIX TRACE — Attack Chain Reconstruction
بازسازی زنجیره حمله از لاگ‌ها
"""
import json, os, sys
from datetime import datetime
from collections import defaultdict, Counter

HOME = os.path.expanduser("~")
LOG_FILE = os.path.join(HOME, "vorix/logs/security/gate09.jsonl")

# رنگ‌ها
R = '\033[0;31m'; G = '\033[0;32m'; Y = '\033[1;33m'
C = '\033[0;36m'; B = '\033[0;34m'; M = '\033[0;35m'; NC = '\033[0m'

def load_logs():
    logs = []
    if not os.path.exists(LOG_FILE):
        return logs
    with open(LOG_FILE) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try: logs.append(json.loads(line))
            except: pass
    return logs

def extract_ip(event):
    meta = event.get("metadata", {})
    for key in ["source_ip", "ip", "src_ip", "client_ip", "attacker"]:
        if key in meta:
            return meta[key]
    return None

def classify(event):
    text = (event.get("message","") + " " + event.get("event_type","")).lower()
    if "sqli" in text or "sql injection" in text or "' or" in text: return "SQL Injection", "💉"
    if "brute" in text or "login fail" in text: return "Brute Force", "🔨"
    if "ddos" in text or "flood" in text: return "DDoS", "🌊"
    if "port scan" in text or "nmap" in text: return "Port Scan", "🔍"
    if "xss" in text or "<script" in text: return "XSS", "🎯"
    if "malware" in text or "backdoor" in text: return "Malware", "☠️"
    if "test" in text: return "Test", "🧪"
    return "Unknown", "❓"

def trace_ip(target_ip):
    """ردیابی کامل یک IP"""
    logs = load_logs()
    if not logs:
        print(f"{R}❌ لاگی نیست{NC}")
        return

    # فیلتر رویدادهای این IP
    events = []
    for e in logs:
        ip = extract_ip(e)
        if ip == target_ip:
            events.append(e)

    if not events:
        print(f"{Y}⚠️  رویدادی از IP {target_ip} پیدا نشد{NC}")
        print(f"{C}💡 IPهای موجود:{NC}")
        ips = Counter(extract_ip(e) for e in logs if extract_ip(e))
        for ip, count in ips.most_common(10):
            print(f"   {ip} → {count} رویداد")
        return

    # مرتب‌سازی زمانی
    events.sort(key=lambda x: x.get("timestamp", ""))

    print(f"\n{M}╔═══════════════════════════════════════════════════════╗{NC}")
    print(f"{M}║  🎯 VORIX TRACE — ردیابی {target_ip:<27} ║{NC}")
    print(f"{M}╚═══════════════════════════════════════════════════════╝{NC}\n")

    # ۱. اطلاعات کلی
    print(f"{C}📊 خلاصه:{NC}")
    print(f"   Total events: {len(events)}")
    print(f"   First seen:   {events[0].get('timestamp','?')[:19]}")
    print(f"   Last seen:    {events[-1].get('timestamp','?')[:19]}")

    # ۲. انواع حملات
    attacks = Counter()
    for e in events:
        at, _ = classify(e)
        attacks[at] += 1

    print(f"\n{C}🎭 انواع حملات:{NC}")
    for at, count in attacks.most_common():
        _, emoji = classify({"message": at.lower()})
        print(f"   {emoji} {at:<20} → {count} بار")

    # ۳. Gate ها
    gates = Counter(e.get("gate","?") for e in events)
    print(f"\n{C}🎯 Gate های هدف:{NC}")
    for gate, count in gates.most_common():
        print(f"   {gate}: {count}")

    # ۴. Timeline
    print(f"\n{C}🕐 Timeline (ترتیب حمله):{NC}")
    print(f"   {'─' * 60}")
    for i, e in enumerate(events[:30], 1):
        ts = e.get("timestamp","?")[:19]
        sev = e.get("severity","?")
        at, emoji = classify(e)

        # رنگ بر اساس severity
        color = {"CRITICAL": R, "ERROR": R, "WARN": Y, "INFO": G}.get(sev, NC)

        msg = e.get("message", "")[:60]
        print(f"   {i:2}. {ts}  {color}[{sev:8}]{NC}  {emoji} {msg}")

    # ۵. اطلاعات GeoIP
    print(f"\n{C}🌍 اطلاعات منبع:{NC}")
    for e in events:
        meta = e.get("metadata", {})
        if "country" in meta or "location" in meta:
            print(f"   Country: {meta.get('country', '?')}")
            print(f"   City:    {meta.get('city', '?')}")
            print(f"   ISP:     {meta.get('isp', '?')}")
            break
    else:
        print(f"   {Y}⚠️ اطلاعات GeoIP ذخیره نشده{NC}")
        print(f"   برای دریافت:")
        print(f"   curl -s 'http://ip-api.com/json/{target_ip}' | python3 -m json.tool")

    # ۶. منابع آلوده (URLs, endpoints)
    endpoints = Counter()
    for e in events:
        meta = e.get("metadata", {})
        if "url" in meta:
            endpoints[meta["url"]] += 1

    if endpoints:
        print(f"\n{C}🎯 Endpoints مورد حمله:{NC}")
        for url, count in endpoints.most_common(5):
            print(f"   {url} → {count} بار")

    # ۷. نتیجه‌گیری
    print(f"\n{M}═══════════════════════════════════════════════════════{NC}")
    print(f"{Y}🎯 نتیجه‌گیری:{NC}")

    critical_count = sum(1 for e in events if e.get("severity") == "CRITICAL")
    blocked_count = sum(1 for e in events if e.get("result") == "BLOCK")

    if critical_count > 5:
        threat_level = f"{R}🔴 بالا — حمله فعال{NC}"
    elif critical_count > 0:
        threat_level = f"{Y}🟠 متوسط — نیاز بررسی{NC}"
    else:
        threat_level = f"{G}🟢 پایین — عادی{NC}"

    print(f"   Threat Level: {threat_level}")
    print(f"   Critical:     {critical_count}")
    print(f"   Blocked:      {blocked_count}")

    if blocked_count == len(events):
        print(f"   {G}✅ همه حملات بلاک شده{NC}")
    else:
        print(f"   {R}⚠️ {len(events) - blocked_count} حمله بلاک نشده{NC}")

    print(f"\n{C}🎯 اقدامات پیشنهادی:{NC}")
    print(f"   1. IP {target_ip} را در Firewall بلاک کن")
    print(f"   2. اگر Brute Force است → Rate Limit")
    print(f"   3. Monitor برای حملات آینده")
    print(f"   4.اگر حساس است → Report به Abuse ISP")

    print(f"\n{M}═══════════════════════════════════════════════════════{NC}\n")

def list_attackers():
    """لیست همه IPهای مهاجم"""
    logs = load_logs()

    attackers = defaultdict(lambda: {"count": 0, "critical": 0, "attacks": Counter()})
    for e in logs:
        ip = extract_ip(e)
        if not ip: continue
        attackers[ip]["count"] += 1
        if e.get("severity") == "CRITICAL":
            attackers[ip]["critical"] += 1
        at, _ = classify(e)
        attackers[ip]["attacks"][at] += 1

    print(f"\n{M}🎯 VORIX — لیست مهاجمین{NC}")
    print(f"{M}═══════════════════════════════════════════════════════{NC}\n")

    if not attackers:
        print(f"{Y}⚠️ هیچ IP مهاجمی ذخیره نشده{NC}")
        return

    # مرتب‌سازی بر اساس تعداد
    sorted_att = sorted(attackers.items(), key=lambda x: -x[1]["count"])

    for ip, info in sorted_att[:20]:
        score = info["critical"] * 10 + info["count"]
        color = R if info["critical"] > 0 else Y
        print(f"{color}{ip:<20}{NC} | رویداد: {info['count']:<4} | بحرانی: {info['critical']:<3}")
        for at, c in info["attacks"].most_common(3):
            print(f"   └─ {at}: {c}")

    print(f"\n{C}💡 برای ردیابی کامل:{NC}")
    print(f"   python3 ~/vorix/trace.py <ip>")
    print()

def show_help():
    print(f"""
{C}🛡️ VORIX TRACE — Attack Chain Reconstruction{NC}

{M}Usage:{NC}
  python3 ~/vorix/trace.py --list              لیست مهاجمین
  python3 ~/vorix/trace.py <ip>                ردیابی یک IP
  python3 ~/vorix/trace.py --help              راهنما

{M}Examples:{NC}
  python3 ~/vorix/trace.py --list
  python3 ~/vorix/trace.py 45.33.32.156
  python3 ~/vorix/trace.py 185.204.169.95
""")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        show_help()
    elif sys.argv[1] == "--list":
        list_attackers()
    elif sys.argv[1] == "--help":
        show_help()
    else:
        trace_ip(sys.argv[1])

#!/data/data/com.termux/files/usr/bin/bash
cd ~/vorix-hybrid/phone

while true; do
    if ! pgrep -f vorix_bot > /dev/null; then
        nohup python vorix_bot.py >> bot.out 2>&1 &
    fi
    if ! pgrep -f layer_livefeed > /dev/null; then
        nohup python layer_livefeed.py >> livefeed.out 2>&1 &
    fi
    sleep 30
done
